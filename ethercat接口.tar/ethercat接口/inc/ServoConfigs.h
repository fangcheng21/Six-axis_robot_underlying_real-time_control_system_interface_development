#ifndef SERVOCONFIGS_H_
#define SERVOCONFIGS_H_

#include <iostream>
#include <semaphore.h> //信号量

#include "ecrt.h"
#include "ectty.h"

#define VID_PID          0x5a65726f,0x00029252      //产品ID和编号
#define PDONUM 19   //PDO地址数量 19

static struct Offset{
    //output
    unsigned int ctrl_word;                                //6040 uint16    控制字
    unsigned int operation_mode;                //6060 int8	切换操作模式
    unsigned int target_position;                   //607a int32 切换到csp模式时 使能需要先读实际位置写入
    unsigned int target_velocity;                   //60ff int32 
    unsigned int target_torque;	                    //6071 int16
    unsigned int drives_digital_outputs;     //60fe  uint32     
    unsigned int home_mode;                         //6098 int8        无效
    unsigned int torque_offset;                         //6082  uint16      无效


    //input
    unsigned int error_code;                                            //603F uint16    错误代码
    unsigned int status_word;                                       //6041 uint16    状态字
    unsigned int modes_of_operation_display;	        //6061 int8	操作模式
    unsigned int position_actual_value;	                    //6064 int32    实际位置    单位cnt
    unsigned int velocity_sensor_actual_value;		//6069 int32    速度传感器实际值
    unsigned int velocity_actual_value;	                    //606c int32    速度实际值      单位cnt/sec
    unsigned int torque_actual_value;                       //6077 int16  值*额定扭矩/1000  力矩实际值
    unsigned int electricity_actual_value;	            //6078 int16 值*额定电流/1000   电流实际值
    unsigned int drives_digital_inputs;                     //60fd uint32 
    unsigned int secondary_encoder;                         //6063 int32   实际位置*


    //空补位
    unsigned int empty_value;                                       //补位 使用6060 int 8
}offset;

/***************************************************************************/
//Config PDOs       PDO数据类型     从站可共用一个
static ec_pdo_entry_info_t device_pdo_entries[] = {
    /*RxPdo 0x1600*/
    {0x607a, 0x00, 32}, /* Target Position */
    {0x6040, 0x00, 16}, /* Control Word */
    {0x6060, 0x00, 8 },
    {0x60ff, 0x00, 32 },
    {0x6071, 0x00, 16},
    {0x60fe, 0x00, 32 },
    {0x6098, 0x00, 8 },
    {0x6082, 0x00, 16 },

    /*TxPdo 0x1A00*/
    {0x6064, 0x00, 32}, /* Position Actual Value */
    {0x6041, 0x00, 16}, /* Status Word */
    {0x603f, 0x00, 16 },
    {0x6061, 0x00, 8 },
    {0x6069, 0x00, 32 },
    {0x606c, 0x00, 32},
    {0x6077, 0x00, 16},
    {0x6078, 0x00, 16},
    {0x60fd, 0x00, 32 },
    {0x6063, 0x00, 32},
    {0x6060, 0x00, 8 }
};

//  PDO个数     Rx8个   Tx11个      
static ec_pdo_info_t device_pdos[] = {
    //RxPdo
    {0x1600, 8, device_pdo_entries + 0 },
    //TxPdo
    {0x1A00, 11, device_pdo_entries + 8 }
};

//  PDO注册数组
static ec_sync_info_t device_syncs[] = {
    { 0, EC_DIR_OUTPUT, 0, NULL, EC_WD_DISABLE },
    { 1, EC_DIR_INPUT, 0, NULL, EC_WD_DISABLE },
    { 2, EC_DIR_OUTPUT, 1, device_pdos + 0, EC_WD_ENABLE },
    { 3, EC_DIR_INPUT, 1, device_pdos + 1, EC_WD_DISABLE },
    { 0xFF}
};

//主站配置类
class MasterConfigs
{
public:
    MasterConfigs()
    {
        master  = nullptr;
        master_state = {};
    }
    ~MasterConfigs()
    {
        master = nullptr;
    }

public:
    // EtherCAT主站配置指针
    ec_master_t *master;
    ec_master_state_t master_state ;
};


//从站配置类
class MotorConfigs
{
public:
    MotorConfigs()
    {
        _sc = nullptr;
        _sc_state = {};
    }

public:
    Offset _offset;

    ec_slave_config_t *_sc;
    ec_slave_config_state_t _sc_state;

};


//机器臂类联合配置（一个主站及六个从站）
class UnityRobotConfigs
{
public:
    //指针传递
    UnityRobotConfigs(MasterConfigs *Mc, MotorConfigs *motor0, MotorConfigs *motor1, MotorConfigs *motor2, MotorConfigs *motor3,
                 MotorConfigs *motor4, MotorConfigs *motor5)
    {
        _master = Mc;
        _motor[0] = motor0;
        _motor[1] = motor1;
        _motor[2] = motor2;
        _motor[3] = motor3;
        _motor[4] = motor4;
        _motor[5] = motor5;

        InitDomainRegs(0, (domain_regs + PDONUM * 0), _motor[0]->_offset);
        InitDomainRegs(1, (domain_regs + PDONUM * 1), _motor[1]->_offset);
        InitDomainRegs(2, (domain_regs + PDONUM * 2), _motor[2]->_offset);
        InitDomainRegs(3, (domain_regs + PDONUM * 3), _motor[3]->_offset);
        InitDomainRegs(4, (domain_regs + PDONUM * 4), _motor[4]->_offset);
        InitDomainRegs(5, (domain_regs + PDONUM * 5), _motor[5]->_offset);

        StateHandler_run = true;
        wakeupTime = {0,0};


    }
    ~UnityRobotConfigs()
    {
        StateHandler_run = false;

        pthread_join(pth, NULL);        //结束心跳线程

        req_real = nullptr ;
    }
private:
    //  PDO地址配置
    void InitDomainRegs(uint16_t num, ec_pdo_entry_reg_t *_domain_regs, Offset &_offset) 
    {
        *(_domain_regs + 0) =    {0,num, VID_PID, 0x607a, 0, &_offset.target_position};
        *(_domain_regs + 1) =    {0,num, VID_PID, 0x6040, 0, &_offset.ctrl_word};
        *(_domain_regs + 2) =    {0,num, VID_PID, 0x6060, 0, &_offset.operation_mode };
        *(_domain_regs + 3) =    {0,num, VID_PID, 0x60ff, 0, &_offset.target_velocity };
        *(_domain_regs + 4) =    {0,num, VID_PID, 0x6071, 0, &_offset.target_torque };
        *(_domain_regs + 5) =    {0,num, VID_PID, 0x60fe, 0, &_offset.drives_digital_outputs };
        *(_domain_regs + 6) =    {0,num, VID_PID, 0x6098, 0, &_offset.home_mode };
        *(_domain_regs + 7) =    {0,num, VID_PID, 0x6082, 0, &_offset.torque_offset };
    
        *(_domain_regs + 8) =    {0,num, VID_PID, 0x6064, 0, &_offset.position_actual_value};
        *(_domain_regs + 9) =    {0,num, VID_PID, 0x6041, 0, &_offset.status_word};
        *(_domain_regs + 10) =    {0,num, VID_PID, 0x603F, 0, &_offset.error_code};
        *(_domain_regs + 11) =    {0,num, VID_PID, 0x6061, 0, &_offset.modes_of_operation_display};
        *(_domain_regs + 12) =    {0,num, VID_PID, 0x6069, 0, &_offset.velocity_sensor_actual_value};
        *(_domain_regs + 13) =    {0,num, VID_PID, 0x606c, 0, &_offset.velocity_actual_value};
        *(_domain_regs + 14) =    {0,num, VID_PID, 0x6077, 0, &_offset.torque_actual_value};
        *(_domain_regs + 15) =    {0,num, VID_PID, 0x6078, 0, &_offset.electricity_actual_value};
        *(_domain_regs + 16) =    {0,num, VID_PID, 0x60fd, 0, &_offset.drives_digital_inputs};
        *(_domain_regs + 17) =    {0,num, VID_PID, 0x6063, 0, &_offset.secondary_encoder};
        *(_domain_regs + 18) =    {0,num, VID_PID, 0x6060, 0, &_offset.empty_value };  //补位
    }

    
public:
    MasterConfigs *_master;      //主站
    MotorConfigs *_motor[6];     //从站
    
    //域指针
    ec_domain_t *domain;
    ec_domain_state_t domain_state ;

    //数据指针
    uint8_t *domain_pd;

    ec_pdo_entry_reg_t domain_regs[PDONUM*6];


    //心跳线程调度
    bool StateHandler_run;       //线程运行标志  赋0值退出线程
    struct timespec wakeupTime;     //应用程序公用时间戳
    struct timespec HeartTime;      //心跳线程时间戳


    struct sched_param param;
    pthread_attr_t thattr;
    pthread_t pth;

    //SDO请求指针
    ec_sdo_request_t *req_real;

};

#endif