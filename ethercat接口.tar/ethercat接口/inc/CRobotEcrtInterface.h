#ifndef CROBOTECRTINTERFACE_H_
#define CROBOTECRTINTERFACE_H_

#include <stdio.h>
#include <string.h>
#include <unistd.h>

#include "ServoConfigs.h"

/***************************时间结构体的定义与转换**************************/
//将时间结构体转换成纳秒
#define NSEC_PER_SEC (1000000000L)  //纳秒数10^9
#define PERIOD_NS (1000000L)  //纳秒数10^6  确定时间周期位置  2ms

#define DIFF_NS(A, B) (((B).tv_sec - (A).tv_sec) * NSEC_PER_SEC + (B).tv_nsec - (A).tv_nsec)

#define TIMESPEC2NS(T) ((uint64_t) (T).tv_sec * NSEC_PER_SEC + (T).tv_nsec)

//  //此处为循环周期时间间隔 1ms
// const struct timespec cycletime = {0, PERIOD_NS};  
/***********************************************************************/

class CRobotEcrtInterface
{
public:
    CRobotEcrtInterface();
    ~CRobotEcrtInterface();

    /********************************初始化部分********************************/
    //获取主站的指针 //请求主机进行实时操作 /*返回：-1表示请求失败，0表示成功*/
    int request_master();

    //获取域指针创建新的进程数据域 /*返回：-1表示请求失败，0表示成功*/
    int create_master_domain();

    //获取从站配置指针 /*返回：-1表示请求失败，0表示成功*/
    int achieve_slave_config();

    //指定完整的PDO配置 /*返回：-1表示请求失败，0表示成功，并有输出显示*/
    int set_slave_config_pdo();

    //注册数据域PDO /*返回：-1表示请求失败，0表示成功*/
    int register_domain_reg_pdo();

    //为从站配置SYNC信号 分布式时钟 /*固定循环时间为1ms,可在PERIOD_NS处修改*/
    void set_slave_dc();

    //将上述6个函数联合 /*返回：-1表示请求失败，0表示成功*/
    int robot_unit_config();


    //读写SDO必须要在激活主站之前 
    //写 SDO  /*参数：关节序号，主索引，次索引，写入数据地址指针，写入数据长度，中止地址*/
    void WriteSdoObject(int motorID, int ObIndex, int ObSubIndex, unsigned char* Value, size_t size, uint32_t *abort_code);

    //读 SDO /*参数：关节序号，主索引，次索引，写入数据地址指针，写入数据长度，中止地址*/
    void ReadSdoObject(int motorID, int ObIndex, int ObSubIndex, unsigned char* Value, size_t size, uint32_t *abort_code);


    //主站正式激活函数 /*返回：-1表示请求失败，0表示成功*/
    int active_master();

    //接收数据域的地址 /*返回：-1表示请求失败，0表示成功，并有输出显示*/
    int achieve_domain_data();

    //激活主站，开启实时控制 /*返回：-1表示请求失败，0表示成功*/
    int active_master_configs();



    /**************************************************************************/
    /***********************************控制部分********************************/
    //下载主站数据 /*参数：主站指针*/
    void receive_master_data(MasterConfigs &mc);

    //下载domain数据 /*参数：URC类*/
    void receive_domain_data(UnityRobotConfigs &urc);

    //下载数据 （联合上述两个）/*参数：URC类*/
    void receive_data();

    //上传domain数据 /*参数：URC类*/
    void send_domain_data();


    //上传从站数据 /*参数：主站指针*/
    void send_master_data(MasterConfigs &mc);

    //上传数据 （联合上述两个）/*参数：URC类*/ 
    void send_data();

    //dc时间控制   
    //将应用时间时间戳写入主站
    //将当前系统时间戳发送给参考时钟 
    //参考时钟发送给所有从站，以实现dc时钟同步/*参数：循环标志符 （int sync_ref_counter = 1）*/
    void master_sync_reference_slave_clock(unsigned int sync_ref_counter);

    /*状态检测*/
    //结合上述两函数实现1000循环检测  /*参数：外部定义记数数 （int cycle_counter = 0）*/
    void cycle_check_domain_master_slave_state(int cycle_counter);


    //绝对睡眠1ms  
    void AbsoluteSleep();

    //同步时间戳
    void SyncTime(struct timespec &times);
    //外部睡眠
    void AbsoluteSleep(struct timespec &times);

    //使能 最大等待时间15s /*参数：关节序号，返回：-1表示请求失败，1表示成功*/
    int ServoOn(int MotorID);

    //去使能 /*参数：关节序号， 返回：-1表示请求失败，1表示成功*/
    int ServoOff(int MotorID);

    //获取电机状态字 /*参数：关节序号， uint16_t状态字*/ 
    void GetServoStatus(int MotorID, uint16_t &Status);

    //获取错误代码 /*参数：关节序号， uint16_t错误代码*/ 
    void GetServoError(int MotorID, uint16_t &Error);

    //获取实际转矩 /*参数：关节序号， int16_t实际转矩*/
    void GetServoTorque(int MotorID, int16_t &Torque);

    //获取目标转矩 /*参数：关节序号， int16_t目标转矩*/
    void GetServoTargetTorque(int MotorID, int16_t &Torque);

    //获取实际位置 /*参数：关节序号， int32_t实际位置*/
    void GetServoPosition(int MotorID, int32_t &Position);

    //获取目标位置 /*参数：关节序号， int32_t目标位置*/
    void GetServoTargetPosition(int MotorID, int32_t &Position);

    //获取运动模式代码  /*参数：关节序号， int8_t运动模式*/
    void GetServoControlMode(int MotorID, int8_t &Mode);

    //快速停止运动  /*参数：关节序号，*/
    void StopServo(int MotorID);

    //报警复位  /*参数：关节序号，*/
    void ResetServoAlarm(int MotorID);

    //控制运动模式 /*参数：关节序号， int8_t运动模式*/
    void SetServoControlMode(int MotorID, int8_t Mode);

    //控制位置 /*参数：关节序号， int32_t 目标位置*/
    void SetServoTargetPosition(int MotorID,int32_t Position);

    //控制转矩 /*参数：关节序号， int16_t 目标转矩*/
    void SetServoTorque(int MotorID, int16_t Torque);

    //IO部分全部暂停
    //output 4位 
    void ReadOutputBit(UnityRobotConfigs &urc, MotorConfigs &moc,int Bitoffset, bool &value);
    //IO
    void WriteOutputBit(UnityRobotConfigs &urc, MotorConfigs &moc,int Bitoffset, bool value);
    //input 6位
    void ReadInputBit(UnityRobotConfigs &urc, MotorConfigs &moc,int Bitoffset, bool &value);
    //存疑
    void ReadInputWord(UnityRobotConfigs &urc, MotorConfigs &moc,int Wordoffset, bool *value);

    //关闭连接 
    void StopLink(); 

    //开启心跳线程 
    int Statehandler_pth();

    //模拟正弦运动控制 /*参数：关节序号，正转/反转：1/-1*/
    int controlMove(int MotorID,int flag);


public:

    struct timespec cycletime;
    pthread_mutex_t mutex;

    MasterConfigs *m_mc;      //主站
    MotorConfigs *m_moc[6];     //从站
    UnityRobotConfigs *m_urc;

};

#endif