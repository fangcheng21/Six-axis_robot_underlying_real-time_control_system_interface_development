/*
*              ZZZZZZZZ    Copyright (c) 2020 IntervalZero, Inc.  All rights reserved.
*            ZZZZ   ZZZZZ
*         O ZZZZ      ZZZ O      Module Name:
*       OII ZZZ        ZZ IOII
*     OIII  ZZZZ      ZZZ  IIII     ksm64shared.h
*    IOIII   ZZZZZ  ZZZZZ   IOII
*    III      ZZZZZZZZZ      IOI   Abstract:
*   III                       III		
*  IIIO     ZZZZZZZZZZZZZ     OIII       
*  IIIO     ZZZZZZZZZZZZZZ     III       
*  III      ZZZ                III   
*  OIII     ZZZ  ZZZZ          III		 
*   IIO     ZZZZZZZZZ         IOIO		 
*   IIII    ZZZZZZ     ZZ     III		
*    IIII   ZZZZ     ZZZZ    III     
*     I0II         ZZZZZZ  OIIOI  Author:
*      IOIO      ZZZZ  ZZ IIII         InterValZero
*        OO       Z    ZZ III
*                      ZZ      Environment:
*           ZZZZZZZZZZZZZ
*           ZZZZZZZZZZZZZ        x64 and  King-Star Motion application 
*                         
*     Revision History:
*		No Revision History
*/
#ifndef _KSMSHARED_H
#define _KSMSHARED_H 0


#include <SDKDDKVer.h>
#include <windows.h>
#include <rtapi.h>
#ifdef UNDER_RTSS
#include <rtssapi.h>
#endif // UNDER_RTSS

#ifdef __cplusplus
extern "C" {
#endif

#ifdef KSM_EXPORTS
#define ksm_API __declspec(dllexport)
#else
#define ksm_API __declspec(dllimport)
#endif

#define KSMAJORVER 3
#define KSMINORVER 7
#define KSMICROVER 0

typedef enum
{
	stateNotReady			= 0,
	stateSwitchOnDis		= 1,
	stateReadyToSwitchOn	= 2,
	stateSwitchedOn			= 3,
	stateOperationEnabled	= 4,
	stateQuickStop			= 5,
	stateMalfunction        = 6,
	stateNotHome			= 7,
	stateHoming				= 8
} CiA402State;

typedef enum
{
        paramPosition = 0,
        paramInternalPosition,
        paramVelocity,
        paramTorque,
        paramPositionError,
        paramTargetPosition,
        paramTargetVelocity,
        paramTorqueOffset,
        paramStatus,
        paramControlMode,
		paramMotionMode,
        paramAccJerk,
        paramAcceleration,
        paramDecJerk,
        paramDeceleration,
        paramMinVelocity,
        paramMaxVelocity,
        paramVelocityRatio,
        paramEllipseScale,
        paramKp,
        paramKi,
        paramKd,
        paramKff,
        paramLowTrigger,
        paramLowKp,
        paramMinError,
        paramMaxError,
        paramMaxIntError,
        paramMinLimit,
        paramMaxLimit,
        paramHomingAcc,
        paramHomingDec,
        paramHomingMinVelocity,
        paramHomingMaxVelocity,
        paramJogVelocity,
        paramIOCtrlVelocity,
        paramEcamTable,
        paramGantryMaster,
        paramAutoTuneMinPos,
		paramAutoTuneMaxPos,
		paramKgantry,
		paramGantryOffset,
		paramDelay
} Param;

typedef enum 
{
    returnNoError			= 0, // Function Succeded
    returnFailed			= -1, // Function Failed
    returnWrongParam		= -2, // A parameter has an incorrect value
    returnWrongEnv			= -3, // The function cannot be called at this time
    returnLinkBusy			= -4 // The Link with Windows is busy
} ReturnCode;

typedef enum 
{
	motionCommandJump = -4,
	motionMaxError	= -3,
    motionMaxLimit	= -2,
    motionMinLimit	= -1,
    motionStopped	= 0,
    motionAcc		= 1,
    motionDec		= 2,
    motionMoving	= 3,
    motionHoming	= 4
} MotionStatus;

typedef enum
{
	homingCommandJump = -4,
	homingMaxError	= -3,
    homingMaxLimit	= -2,
    homingMinLimit	= -1,
    homingStandby	= 0,
    homingRunning	= 1,
    homingAborting	= 2,
    homingSuccess	= 3
} HomingStatus;

typedef enum
{
    ecatOffline		= 0,
    ecatInit		= 1,
    ecatPreOP		= 2,
    ecatSafeOP		= 4,
    ecatOP			= 8
} EcatState;

typedef enum 
{
    accessPos			= 0,
    accessVel			= 1,
    accessPosVel		= 3,
    accessVelPos		= 4
} AccessMode;

typedef enum
{
	modeDirectPos			= 5,
	modeDirectVel			= 0,
	modeDirectTor			= 4,
    modeMasterIntPos		= 2,
    modeMasterIntVel		= 1,
	modeMasterIntTor		= 6,
	modePidVel				= 7,
	modePidTor				= 8,
	modeSlaveInt			= 3
} ControlMode;

typedef enum
{
	homingLatch			= 0,
	homingSoft			= 1,
	homingSensor		= 2,
	homingSlave			= 3,
	homingOnPosition	= 4
} HomingMode;

typedef enum
{
	directionReverse			= -1,
	directionForward			= 1
} HomingDirection;

typedef enum {
	cycle100	= 100,
	cycle125	= 125,
	cycle250	= 250,
	cycle500	= 500,
	cycle1000	= 1000,
	cycle2000	= 2000
} CycleTime;

typedef enum {
	noError				= 0,
	ethNotConnected		= 1,
	noSlave				= 2,
	slaveNotSupported	= 3,
	noLicense			= 4,
	cannotReachInit		= 5,
	cannotReachPreop	= 6,
	cannotReachSafeop	= 7,
	cannotReachOp		= 8
} StartupErrorCode;

typedef enum
{
	profileUnitPerSecond	= 0,
	profileDelayInSecond	= 1
} MotionProfileType;

typedef enum
{
	featureServoInput		= 0,
	featureServoOutput		= 1,
	featureInternalPos		= 2,
	featureTorqueControl	= 3,
	featureSyncControlMode	= 4,
	featureAutoRestart		= 5,
	featureAutoRepair		= 6,
	featureAutoConfig		= 7,
	featureDcMasterShift	= 8,
	featureDcCheck			= 9
}Feature;

typedef enum
{
	fullStep1000 = 1000,
	fullStep2000 = 2000,
	fullStep4000 = 4000,
	fullStep8000 = 8000,
	fullStep16000 = 16000,
	fullStep32000 = 32000
}StepperFullStep;

typedef struct {
    CiA402State			CiA402State;
    BOOL				Warning;
    BOOL				Fault;
	BOOL				InTarget;
	BOOL				LimitActive;
}ServoStatus;

typedef struct  {
	char				Name[64];
    unsigned int	    VendorId;
    unsigned int		ProductCode;
	unsigned int		RevisionNumber;
	unsigned int		SerialNumber;
	unsigned int		SlaveId;
	unsigned short      AliasAddress;
	unsigned short      PhysAddress;
	unsigned short		SlaveState;
	unsigned short		Status;
	double				Pitch;
	unsigned int		EncoderRes;
	unsigned int		InputLength;
	unsigned int		OutputLength;
	unsigned int		CycleTime;
	unsigned int		VariableIndexOffset;
}SlaveStatus;

typedef struct {
	int					EcatState;
	int					SlaveCount;
	int					IOCount;
	int					ServoCount;
	int					LostFrameCount;
}MasterStatus;

typedef struct 
{
	double  FeedbackDelay;      // Feedback Delay;
	double  KP;                 // Proportional Gain;
	double  KI;                 // Integral Gain;
	double  KILimitPercent;     // KI Term Limit in Percent for Torque and Percent of MaxOutput for Velocity;
	double  KD;                 // Derivative Gain;
	double  KV;                 // Velocity Feedforward Gain;
	double  KAA;                // Acceleration Feedforward Gain (Accel);
	double  KAD;                // Deceleration Feedforward Gain (Decel);
	double	KJ;					// Jerk Feedforward Gain;
	double  ReducedGainsDelay;  // KP and KD Reduced after this Delay in Seconds;
	double  RgFactor;           // KP and KD multiplied by this Factor (after Delay);
	BOOL    KIStoppedOnly;      // KI is only used when stopped;
	BOOL    KDUseInternalPos;   // KD uses the Internal Position encoder;
	double	MinError;			// Position Error Below which the drive is considered in target;
	double	MaxError;			// Maximum Following Error;
	double	MaxOutput;			// Maximum Output of the PID. Maximum Torque in % or Maximum Velocity
}PidSettings;

typedef struct
{
	double	MinimumVelocity;
	double	MaximumVelocity;
	double	Acceleration;
	double	Deceleration;
	double	AccelerationJerk;
	double	DecelerationJerk;
	double	Jolt;
}ProfileSettings;
typedef enum
{
	mcAborting			= 0,
	mcBuffered			= 1,
	mcBlendingLow		= 2,
	mcBlendingPrevious	= 3,
	mcBlendingNext		= 4,
	mcBlendingHigh		= 5,
	mcCancel			= 6
} MC_BufferMode;

typedef enum
{
	mcPositiveDirection	= 0,
	mcShortestWay		= 1,
	mcNegativeDirection = 2,
	mcCurrentDirection	= 3
} MC_Direction;

typedef enum
{
	mcImmediately		= 0,
	mcQueued			= 1
} MC_ExecutionMode;
typedef enum
{
	mcCommandedPosition			= 1,
	mcSoftLimitPositive			= 2,
	mcSoftLimitNegative			= 3,
	mcEnableLimitPositive		= 4,
	mcEnableLimitNegative		= 5,
	mcEnablePosLagMonitoring	= 6,
	mcMaxPositionLag			= 7,
	mcMaxVelocitySystem			= 8,
	mcMaxVelocityApplication	= 9,
	mcActualVelocity			= 10,
	mcCommandedVelocity			= 11,
	mcMaxAccelerationSystem		= 12,
	mcMaxAccelerationApplication = 13,
	mcMaxDecelerationSystem		= 14,
	mcMaxDecelerationApplication = 15,
	mcMaxJerkSystem				= 16,
	mcMaxJerkApplication		= 17,
	mcInterpolationTime			= 1001,
	mcControlMode				= 1002,
	mcMotionProfileType			= 1003,
	mcHomingMode				= 1004,
	mcHomeSensorModuleType		= 1005,
	mcHomeSensorModuleIndex		= 1006,
	mcHomeSensorOffset			= 1007,
	mcInvertHomeSensor			= 1008,
	mcMinHomingVelocity			= 1009,
	mcMaxHomingVelocity			= 1010,
	mcHomingAcceleration		= 1011,
	mcHomingDeceleration		= 1012,
	mcSensorLimitPosModuleType	= 1013,
	mcSensorLimitPosModuleIndex	= 1014,
	mcSensorLimitPosOffset		= 1015,
	mcInvertSensorLimitPos		= 1016,
	mcEnableSensorLimitPos		= 1017,
	mcSensorLimitNegModuleType	= 1018,
	mcSensorLimitNegModuleIndex	= 1019,
	mcSensorLimitNegOffset		= 1020,
	mcInvertSensorLimitNeg		= 1021,
	mcEnableSensorLimitNeg		= 1022,
	mcCountPerUnitNumerator		= 1023,
	mcCountPerUnitDenominator	= 1024,
	mcCountPerUnitReverse		= 1025,
	mcTorquePolarityReverse		= 1026,
	mcRealUnitConversion		= 1027,
	mcMinVelocitySystem			= 1028,
	mcMinPositionLag			= 1029,
	mcActualPositionLag			= 1030,
	mcHomingDirection			= 1031,
	mcSlaveHomeOffset			= 1032,
	mcSlaveHomingMode			= 1033,
	mcSlaveControlLimit			= 1034,
	mcCancelHome				= 1035,
	mcFeedbackDelay				= 1036,
	mcKp						= 1037,
	mcKi						= 1038,
	mcKiLimitPercent			= 1039,
	mcKd						= 1040,
	mcKv						= 1041,
	mcKaa						= 1042,
	mcKad						= 1043,
	mcKj						= 1044,
	mcReducedGainsDelay			= 1045,
	mcRgFactor					= 1046,
	mcKiStoppedOnly				= 1047,
	mcKdUseInternalPos			= 1048,
	mcPosToVelRatio				= 1049,
	mcPowerOnPositive			= 1050,
	mcPowerOnNegative			= 1051
} MC_AxisParameter;
typedef enum
{
	mcCommandedValue	= 0,
	mcSetValue			= 1,
	mcActualValue		= 2
} MC_Source;
typedef enum
{
	mcErrorStop				= 0,
	mcDisabled				= 1,
	mcStandStill			= 2,
	mcStopping				= 3,
	mcHoming				= 4,
	mcDiscreteMotion		= 5,
	mcContinuousMotion		= 6,
	mcSynchronizedMotion	= 7
} MC_AxisStatus;
typedef enum
{
	mcNoError					= 0,
	mcNullParameter				= 1,
	mcWrongParameter			= 2,
	mcWrongEnvironment			= 3,
	mcLinkBusy					= 4,
	mcCommandBufferFull			= 5,
	mcWrongQueueIndex			= 6,
	mcWrongAxisState			= 7,
	mcWrongControlMode			= 8,
	mcNoSensorDefined			= 9,
	mcTimeout					= 10,
	mcFollowingError			= 11,
	mcMinimumLimit				= 12,
	mcMaximumLimit				= 13,
	mcFileNotFound				= 14,
	mcCommandJump				= 15,
	mcSdoToggleBit				= 100,
	mcSdoTimeout				= 101,
	mcSdoCommandSpecifier		= 102,
	mcSdoOutOfMemory			= 103,
	mcSdoUnsupportedAccess		= 104,
	mcSdoWriteOnly				= 105,
	mcSdoReadOnly				= 106,
	mcSdoSubindexReadOnly		= 107,
	mcSdoNoCompleteAccess		= 108,
	mcSdoObjectTooLong			= 109,
	mcSdoObjectInPdo			= 110,
	mcSdoObjectNotExist			= 111,
	mcSdoNoPdoMapping			= 112,
	mcSdoPdoLengthExceeded		= 113,
	mcSdoParameterIncompatible	= 114,
	mcSdoInternalIncompatible	= 115,
	mcSdoHardwareError			= 116,
	mcSdoLengthIncorrect		= 117,
	mcSdoLengthTooHigh			= 118,
	mcSdoLengthTooLow			= 119,
	mcSdoSubindexNotExist		= 120,
	mcSdoValueOutOfRange		= 121,
	mcSdoValueTooHigh			= 122,
	mcSdoValueTooLow			= 123,
	mcSdoMaxBelowMin			= 124,
	mcSdoGeneralError			= 125,
	mcSdoCannotTransfer			= 126,
	mcSdoCannotTransferLocal	= 127,
	mcSdoWrongState				= 128,
	mcSdoDictionaryNotAvailable = 129
} MC_Error;

#define	REAL	double
#define	LREAL	double
typedef struct  {
	INT Index;
}IDENT_IN_GROUP;

typedef enum
{
	mcAxisCoordSystem			= 0,
	mcMachineCoordSystem		= 1,
	mcProductCoordSystem		= 2
} MC_CoordSystem;

typedef enum
{
	mcNone						= 0,
	mcCornerDistance			= 3,
	mcMaxCornerDeviation		= 4
} MC_TransitionMode;

typedef enum
{
	mcBorder					= 0,
	mcCenter					= 1,
	mcRadius					= 2
} MC_CircMode;

typedef enum
{
	mcShortPath					= 0,
	mcLongPath					= 1
} MC_CircPathChoice;

typedef struct {
	int		BufferLength;
	int		DeviceCount;
	int		AxisCount;
	int		IoCount;
	char* 	AxisNames;
	char* 	IoNames;
	int*	InputLengths;
	int*	OutputLengths;
} ScannedNetwork;

typedef enum
{
	logAxis = 1,
	logGroup = 2,
	logInput = 3,
	logOutput = 4
} MC_LogSource;

typedef enum
{
	logActualPosition = 1,
	logActualVelocity = 2,
	logActualTorque = 3,
	logActualCurrent = 4,
	logFollowingError = 5,
	logInternalPosition = 6,
	logCommandPosition = 7,
	logCommandVelocity = 8,
	logCommandTorque = 9,
	logCommandAcceleration = 10,
	logCommandJerk = 11,
	logDigitalInputs = 12,
	logDigitalOutputs = 13
} MC_LogVariable;

typedef enum
{
	logBool = 1,
	logByte = 2,
	logSInt = 3,
	logWord = 4,
	logInt = 5,
	logDWord = 6,
	logDInt = 7,
	logFloat = 8,
	logLWord = 9,
	logLInt = 10,
	logDouble = 11
} MC_LogDataType;

typedef enum
{
	logImmediately = 1,
	logAboveLimit = 2,
	logBelowLimit = 3,
	logAboveAbs = 4,
	logBelowAbs = 5
} MC_LogTriggerType;

typedef struct
{
	MC_LogSource		Source;
	INT					Index;
	MC_LogVariable		Variable;
	INT					Offset;
	MC_LogDataType		DataType;
} MC_LogChannel;

typedef enum
{
	camLinear = 1,
	camPoly5 = 2
} MC_CamInterpolationType;

typedef enum
{
	camAbsolute = 1,
	camRelative = 2,
	camRampDistance = 3,
	camRampTime = 4
} MC_CamStartMode;

typedef struct
{
	INT					Length;
	BOOL				MasterAbsolute;
	BOOL				SlaveAbsolute;
	BOOL				Periodic;
	MC_CamInterpolationType InterpolationType;
} MC_CamTable;

typedef enum
{
	mcShortest = 0,
	mcCatchUp = 1,
	mcSlowDown = 2
} MC_SyncMode;

typedef enum
{
	ksmDisposed = 0,
	ksmInitialized,
	ksmCreated,
	ksmWaitNic,
	ksmScanBus,
	ksmLoadTemplate,
	ksmAutoConfig,
	ksmLoadEni,
	ksmToInit,
	ksmToPreOp,
	ksmScanMdp,
	ksmInitMemory,
	ksmStartDc,
	ksmToSafeOp,
	ksmSyncDc,
	ksmToOp,
	ksmWaitData,
	ksmStarted,
	ksmStopping
} KSM_State;

typedef struct
{
	INT					TouchProbeID;
	BOOL				Software;
	BOOL				Edge;
	BOOL				IndexPulse;
	BOOL				Axis;
	INT					Index;
	INT					Offset;
} MC_ProbeTrigger;

typedef struct
{
	INT					TrackNumber;
	LREAL				FirstOnPosition;
	LREAL				LastOnPosition;
	INT					AxisDirection;
	INT					CamSwitchMode;
	LREAL				Duration;
} MC_CamSwitch;

typedef struct
{
	BOOL				Axis;
	INT 				Index;
	INT 				Offset;
} MC_Output;

typedef struct
{
	LREAL				OnCompensation;
	LREAL				OffCompensation;
	LREAL				Hysteresis;
} MC_Track;

typedef struct
{
	USHORT	Index;
	BYTE	SubIndex;
	INT		Length;
	BYTE	Data[8];
} SdoCommand;

typedef struct
{
	UCHAR		Revision;
	UCHAR		Spdu;
	USHORT		Control;
	INT			InputLength;
	INT			OutputLength;
} IoLinkSetting;

typedef struct
{
	BOOL		Enable;
	INT			Length;
	USHORT		Index;
	BYTE		Trigger;
} CanPdo;

typedef struct
{
	INT			RxPdoCount;
	CanPdo		RxPdos[4];
	INT			TxPdoCount;
	CanPdo		TxPdos[4];
	INT			SdoCommandCount;
	SdoCommand	SdoCommands[16];
} CanOpenSetting;

typedef struct
{
	INT			InputLength;
	INT			OutputLength;
	INT			SdoCommandCount;
	SdoCommand	SdoCommands[16];
} EcatMdpSetting;

typedef enum
{
	protoEtherCAT = 1,
	protoIoLink = 2,
	protoCANopen = 3,
	protoEl6695Secondary = 4,
	protoEl6695Primary = 5,
	protoEsi = 6
} CouplerProtocol;

typedef struct {
	unsigned short	Index;
	unsigned short	DataType;
	unsigned char	MaxSubIndex;
	unsigned char	ObjectCode;
	char			Name[64];
} SdoObjectDescription;

typedef struct {
	unsigned short	Index;
	unsigned char	SubIndex;
	unsigned char	ValueInfo;
	unsigned short	DataType;
	unsigned short	BitLength;
	unsigned short	ObjectAccess;
	unsigned char	Data[64];
} SdoEntryDescription;

typedef struct
{
	INT	PowerStatusModule;
	INT	PowerStatusOffset;
	BOOL PowerStatusInvert;
	INT	AlarmModule;
	INT	AlarmOffset;
	BOOL AlarmInvert;
	INT	PowerControlModule;
	INT	PowerControlOffset;
	BOOL PowerControlInvert;
	INT	ResetModule;
	INT	ResetOffset;
	BOOL ResetInvert;
	INT	EncoderModule;
	INT	EncoderOffset;
	INT EncoderLength;
	INT	TargetPositionModule;
	INT	TargetPositionOffset;
	INT TargetPositionLength;
	INT	TargetVelocityModule;
	INT	TargetVelocityOffset;
	INT TargetVelocityLength;
	INT	TargetTorqueModule;
	INT	TargetTorqueOffset;
	INT TargetTorqueLength;
} VirtualAxis;


#define MAXLOG	10000

/////////////////////////////
/* RTX Functions */
/////////////////////////////
ksm_API void __stdcall RTX_ShutdownHandler(BOOL Enable, BOOL* Enabled, BOOL* Shutdown, BOOL* Error, WORD* ErrorID);

/////////////////////////////
/* EtherCAT Link Functions */
/////////////////////////////
ksm_API BOOL __stdcall Initialized();
ksm_API BOOL __stdcall Created();
ksm_API BOOL __stdcall Started();
ksm_API int __stdcall InitializeLink(int Affinity);
ksm_API int __stdcall ScanBus(ScannedNetwork* Network);
ksm_API int __stdcall CreateLink();
ksm_API int __stdcall SetNIC(char* Card, int Instance);
ksm_API int __stdcall SetInterpolation(CycleTime Cycle);
ksm_API int __stdcall SetAccessMode(AccessMode Mode);
ksm_API int __stdcall EnableVerbosity(BOOL Active);
ksm_API int __stdcall EnableServoInputAccess(BOOL Active);
ksm_API int __stdcall EnableServoOutputAccess(BOOL Active);
ksm_API int __stdcall EnableInternalPositionAccess(BOOL Active);
ksm_API int __stdcall EnableTorqueControl(BOOL Active);
ksm_API int __stdcall EnableSynchronizedControlMode(BOOL Active);
ksm_API int __stdcall EnableAutoRestart(BOOL Active);
ksm_API int __stdcall EnableAutoRepair(BOOL Active);
ksm_API int __stdcall EnableAutoConfig(BOOL Active);
ksm_API int __stdcall EnableDcMasterShift(BOOL Active);
ksm_API int __stdcall EnableDcCheck(BOOL Active);
ksm_API int __stdcall StartLink();
ksm_API int __stdcall GetStartupError(int* ErrorCode, char* ErrorMessage);
ksm_API int __stdcall RestartLink();
ksm_API int __stdcall RestartSlave(int SlaveId);
ksm_API int __stdcall GetLinkStatus(MasterStatus* Status);
ksm_API int __stdcall GetLinkState();
ksm_API int __stdcall GetSlaveById(int SlaveId, SlaveStatus* Status);
ksm_API int __stdcall GetInterpolation(CycleTime* Cycle);
ksm_API int __stdcall GetAccessMode(AccessMode* Mode);
ksm_API int __stdcall GetVerbosity(BOOL* verbosity);
ksm_API int __stdcall GetFeature(Feature Feature, BOOL* Active);
ksm_API int __stdcall UseAliases(BOOL Active);
ksm_API int __stdcall AliasUsed(BOOL* Active);
ksm_API int __stdcall StopLink();
ksm_API int __stdcall DisposeLink();
ksm_API int __stdcall GetDCSystemTime(BOOL Next, DWORD64* Time);
ksm_API int __stdcall ConfigHeartbeat(BOOL Enable, LREAL Timeout);
ksm_API void __stdcall PulseHeartbeat();
ksm_API int __stdcall ConfigLinkedDevice(int ethercatSlaveId, int linkedDeviceId, int protocol, VOID* settings);
ksm_API int __stdcall StartFromConfiguration(char* Configuration);

/////////////////////////////
/* Servo Module Functions  */
/////////////////////////////
ksm_API int __stdcall ConfigureServoCount(int ServoCount);
ksm_API int __stdcall GetConfiguredServoCount(int* ServoCount);
ksm_API int __stdcall ConfigureServo(int Index, SlaveStatus Servo);
ksm_API int __stdcall SetVirtualAxis(int Index, VirtualAxis axis);
ksm_API int __stdcall GetServoByIndex(int Index, SlaveStatus* Status);
ksm_API int __stdcall SetServoAlias(int Index, int Alias);
ksm_API int __stdcall GetServoAlias(int Index, int* Alias);
ksm_API int __stdcall GetServoStatus(int Index, ServoStatus* Status);
ksm_API int __stdcall GetServoControlMode(int Index, ControlMode* Mode);
ksm_API int __stdcall GetServoAvailableControlModes(int Index, int* Modes);
ksm_API int __stdcall SetServoControlMode(int Index, ControlMode Mode);
ksm_API int __stdcall GetServoInterpolation(int Index, int* Cycle);
ksm_API int __stdcall SetServoInterpolation(int Index, int Cycle);
ksm_API int __stdcall SetStepperFullStep(int Index, StepperFullStep FullStep);
ksm_API int __stdcall SetServoTargetPosition(int Index, double Position);
ksm_API int __stdcall SetServoVelocity(int Index, double Velocity);
ksm_API int __stdcall SetServoTorque(int Index, double Torque);
ksm_API int __stdcall SetServoTorqueOffset(int Index, double Torque);
ksm_API int __stdcall SetServoHomingMode(int Index, HomingMode Mode);
ksm_API int __stdcall ReadServoDI(int Index, DWORD* Value);
ksm_API int __stdcall ForceServoDI(int Index, DWORD Value);
ksm_API int __stdcall ReadServoDO(int Index, DWORD* Value);
ksm_API int __stdcall WriteServoDO(int Index, DWORD Value);
ksm_API int __stdcall ServoOn(int Index);
ksm_API int __stdcall ServoOff(int Index);
ksm_API int __stdcall SetServoAsEcamSlave(int Index, int TableIndex);
ksm_API int __stdcall RemoveServoAsSlave(int Index);
ksm_API int __stdcall ResetServoAlarm(int Index);
ksm_API int __stdcall ConfigServoParam(Param Param, int Length, int* Indexes, double* Values);
ksm_API int __stdcall ReadServoParam(Param Param, int Length, int* Indexes, double* Values);
ksm_API int __stdcall SetServoMotionProfileType(int Index, MotionProfileType Type);
ksm_API int __stdcall ConfigServoMotion(int Index, ProfileSettings Settings);
ksm_API int __stdcall ConfigServoHoming(int Index, double Acc, double Dec, double MinVel, double MaxVel);
ksm_API int __stdcall SetServoHomeInput(int Index, BOOL ServoSensor, int ModuleIndex, int BitOffset);
ksm_API int __stdcall SetServoMaxSensor(int Index, BOOL ServoSensor, int ModuleIndex, int BitOffset, BOOL Invert);
ksm_API int __stdcall SetServoMinSensor(int Index, BOOL ServoSensor, int ModuleIndex, int BitOffset, BOOL Invert);
ksm_API int __stdcall SetServoEncoderResolution(int Index, double Resolution);
ksm_API int __stdcall SetServoPitch(int Index, double Pitch);
ksm_API int __stdcall SetServoPitchRatio(int Index, double Ratio);
ksm_API int __stdcall SetServoCountsPerUnit(int Index, double Numerator, double Denominator, BOOL Reverse);
ksm_API int __stdcall SetServoInternalCountsPerUnit(int Index, double Numerator, double Denominator, BOOL Reverse);
ksm_API int __stdcall ReverseServoTorquePolarity(int Index, BOOL Reverse);
ksm_API int __stdcall SetServoRealUnits(int Index, BOOL Active);
ksm_API int __stdcall SetServoReverse(int Index, BOOL Active);
ksm_API int __stdcall SetServoUseInternalPosition(int Index, BOOL Active);
ksm_API int __stdcall ConfigServoSimplePid(int Index, double Kp, double Ki, double Kd, double RgDelay, double RgFactor);
ksm_API int __stdcall ConfigServoVelPid(int Index, PidSettings Settings);
ksm_API int __stdcall GetServoVelPid(int Index, PidSettings* Settings);
ksm_API int __stdcall ConfigServoTorPid(int Index, PidSettings Settings);
ksm_API int __stdcall GetServoTorPid(int Index, PidSettings* Settings);
ksm_API int __stdcall MoveServoJog(int Index, double Velocity);
ksm_API int __stdcall MoveServoRelative(int Index, double Distance);
ksm_API int __stdcall MoveServoAbsolute(int Index, double Target);
ksm_API int __stdcall DefineServoRelative(int Index, double Distance);
ksm_API int __stdcall DefineServoAbsolute(int Index, double Target);
ksm_API int __stdcall SimulateServoRelative(int Index, double Distance, double* AccTime, double* DecTime, double* Duration);
ksm_API int __stdcall SimulateServoAbsolute(int Index, double Target, double* AccTime, double* DecTime, double* Duration);
ksm_API int __stdcall MoveServo(int Length, int* Axes);
ksm_API int __stdcall StopServo(int Index);
ksm_API int __stdcall QuickStopServo(int Index);
ksm_API int __stdcall GetServoPosition(int Index, double* Position);
ksm_API int __stdcall GetServoInternalPos(int Index, double* Position);
ksm_API int __stdcall GetServoSetPosition(int Index, double* Position);
ksm_API int __stdcall GetServoVelocity(int Index, double* Velocity);
ksm_API int __stdcall GetServoTargetVelocity(int Index, double* Velocity);
ksm_API int __stdcall GetServoTorque(int Index, double* Torque);
ksm_API int __stdcall GetServoTargetTorque(int Index, double* Torque);
ksm_API int __stdcall GetServoTorqueOffset(int Index, double* Torque);
ksm_API int __stdcall SetServoPosition(int Index, double Position);
ksm_API int __stdcall SetServoInternalPosition(int Index, double Position);
ksm_API int __stdcall SetServoFeedback(int Index, double Feedback);
ksm_API int __stdcall GetServoPositionError(int Index, double* Error);
ksm_API int __stdcall GetServoMotionStatus(int Index, MotionStatus* Status);
ksm_API int __stdcall GetHomingStatus(int Index, HomingStatus* Status);
ksm_API int __stdcall StartHoming(int Index, HomingDirection Direction);
ksm_API int __stdcall AbortHoming(int Index);
ksm_API int __stdcall GetServoCustomInput1(int Index, int* Value);
ksm_API int __stdcall GetServoCustomInput2(int Index, int* Value);
ksm_API int __stdcall SetServoCustomOutput1(int Index, int Value);
ksm_API int __stdcall SetServoCustomOutput2(int Index, int Value);

/////////////////////////////
/* IO Module Functions     */
/////////////////////////////
ksm_API int __stdcall ConfigureIoCount(int IoCount);
ksm_API int __stdcall GetConfiguredIoCount(int* IoCount);
ksm_API int __stdcall ConfigureIo(int Index, SlaveStatus Io);
ksm_API int __stdcall GetIOByIndex(int Index, SlaveStatus* Status);
ksm_API int __stdcall SetIOAlias(int Index, int Alias);
ksm_API int __stdcall GetIOAlias(int Index, int* Alias);
ksm_API int __stdcall WriteOutputBit(int Index, int BitOffset, BOOL Value);
ksm_API int __stdcall WriteOutputWord(int Index, int WordOffset, WORD Value);
ksm_API int __stdcall WriteOutputWordB(int Index, int ByteOffset, WORD Value);
ksm_API int __stdcall WriteOutputDWord(int Index, int DWordOffset, DWORD Value);
ksm_API int __stdcall WriteOutputDWordB(int Index, int ByteOffset, DWORD Value);
ksm_API int __stdcall ReadOutputBit(int Index, int BitOffset, BOOL* Value);
ksm_API int __stdcall ReadOutputWord(int Index, int WordOffset, WORD* Value);
ksm_API int __stdcall ReadOutputWordB(int Index, int ByteOffset, WORD* Value);
ksm_API int __stdcall ReadOutputDWord(int Index, int DWordOffset, DWORD* Value);
ksm_API int __stdcall ReadOutputDWordB(int Index, int ByteOffset, DWORD* Value);
ksm_API int __stdcall ForceInputBit(int Index, int BitOffset, BOOL Value);
ksm_API int __stdcall ForceInputWord(int Index, int ByteOffset, WORD Value);
ksm_API int __stdcall ForceInputDWord(int Index, int ByteOffset, DWORD Value);
ksm_API int __stdcall ReadInputBit(int Index, int BitOffset, BOOL* Value);
ksm_API int __stdcall ReadInputWord(int Index, int WordOffset, WORD* Value);
ksm_API int __stdcall ReadInputWordB(int Index, int ByteOffset, WORD* Value);
ksm_API int __stdcall ReadInputDWord(int Index, int DWordOffset, DWORD* Value);
ksm_API int __stdcall ReadInputDWordB(int Index, int ByteOffset, DWORD* Value);
ksm_API int __stdcall GetMemoryPointer(LPVOID* ppMemory);
ksm_API int __stdcall WriteMemoryBit(int Offset, int BitOffset, BOOL Value);
ksm_API int __stdcall WriteMemoryByte(int Offset, BYTE Value);
ksm_API int __stdcall WriteMemoryWord(int Offset, WORD Value);
ksm_API int __stdcall WriteMemoryDWord(int Offset, DWORD Value);
ksm_API int __stdcall WriteMemoryLWord(int Offset, DWORD64 Value);
ksm_API int __stdcall ReadMemoryBit(int Offset, int BitOffset, BOOL* Value);
ksm_API int __stdcall ReadMemoryByte(int Offset, BYTE* Value);
ksm_API int __stdcall ReadMemoryWord(int Offset, WORD* Value);
ksm_API int __stdcall ReadMemoryDWord(int Offset, DWORD* Value);
ksm_API int __stdcall ReadMemoryLWord(int Offset, DWORD64* Value);

/////////////////////////////
/* Mailbox Functions       */
/////////////////////////////
ksm_API int __stdcall ReadSdoObject(int SlaveID, int ObIndex, int ObSubIndex, unsigned char* Value, unsigned long Length);
ksm_API int __stdcall WriteSdoObject(int SlaveID, int ObIndex, int ObSubIndex, unsigned char* Value, unsigned long Length);
ksm_API int __stdcall ReadSdoODList(int SlaveID, int ListType, unsigned char* Data, unsigned long Length, unsigned long* LengthRead);
ksm_API int __stdcall ReadSdoObjectDescription(int SlaveID, SdoObjectDescription* Data);
ksm_API int __stdcall ReadSdoEntryDescription(int SlaveID, SdoEntryDescription* Data);
ksm_API int __stdcall SetSlaveEoeIp(int SlaveID, unsigned long long Mac, unsigned long Ip, unsigned long Subnet, unsigned long Gateway, unsigned long Dns, char* DnsName);
ksm_API int __stdcall AoeReadSdoObject(int SlaveID, int Port, int ObIndex, int ObSubIndex, unsigned char* Value, unsigned long Length);
ksm_API int __stdcall AoeWriteSdoObject(int SlaveID, int Port, int ObIndex, int ObSubIndex, unsigned char* Value, unsigned long Length);
ksm_API int __stdcall AoeReadCommand(int SlaveID, int Port, unsigned int IndexGroup, unsigned int IndexOffset, unsigned char* Value, unsigned long Length);
ksm_API int __stdcall AoeWriteCommand(int SlaveID, int Port, unsigned int IndexGroup, unsigned int IndexOffset, unsigned char* Value, unsigned long Length);
ksm_API int __stdcall AoeWriteControlCommand(int SlaveID, int Port, unsigned short AoeState, unsigned short DeviceState, unsigned char* Value, unsigned long Length);
ksm_API int __stdcall AoeReadWriteCommand(int SlaveID, int Port, unsigned int IndexGroup, unsigned int IndexOffset, unsigned char* ReadValue, unsigned long ReadLength, unsigned char* WriteValue, unsigned long WriteLength);

/////////////////////////////
/* PLC Open Motion Control */
/////////////////////////////
ksm_API void __stdcall MC_AbortCommand(int Index, INT QueueIndex, BOOL* Done, BOOL* Error, WORD* ErrorID);
ksm_API void __stdcall MC_Power(int Index, BOOL Enable, BOOL EnablePositive, BOOL EnableNegative, BOOL* Status, BOOL* Valid, BOOL* Error, WORD* ErrorID);
ksm_API void __stdcall MC_Home(int Index, INT* QueueIndex, LREAL Position, MC_BufferMode BufferMode, BOOL* Done, BOOL* Busy, BOOL* Active, BOOL* CommandAborted, BOOL* Error, WORD* ErrorID);
ksm_API void __stdcall MC_Stop(int Index, INT* QueueIndex, BOOL Execute, LREAL Deceleration, LREAL Jerk, BOOL* Done, BOOL* Busy, BOOL* CommandAborted, BOOL* Error, WORD* ErrorID);
ksm_API void __stdcall MC_Halt(int Index, INT* QueueIndex, LREAL Deceleration, LREAL Jerk, MC_BufferMode BufferMode, BOOL* Done, BOOL* Busy, BOOL* Active, BOOL* CommandAborted, BOOL* Error, WORD* ErrorID);
ksm_API void __stdcall MC_MoveAbsolute(int Index, INT* QueueIndex, BOOL ContinuousUpdate, LREAL Position, LREAL Velocity, LREAL Acceleration, LREAL Deceleration, LREAL Jerk, MC_Direction Direction, MC_BufferMode BufferMode, BOOL* Done, BOOL* Busy, BOOL* Active, BOOL*CommandAborted, BOOL* Error, WORD* ErrorID);
ksm_API void __stdcall MC_MoveRelative(int Index, INT* QueueIndex, BOOL ContinuousUpdate, LREAL Distance, LREAL Velocity, LREAL Acceleration, LREAL Deceleration, LREAL Jerk, MC_BufferMode BufferMode, BOOL* Done, BOOL* Busy, BOOL* Active, BOOL*CommandAborted, BOOL* Error, WORD* ErrorID);
ksm_API void __stdcall MC_MoveAdditive(int Index, INT* QueueIndex, BOOL ContinuousUpdate, LREAL Distance, LREAL Velocity, LREAL Acceleration, LREAL Deceleration, LREAL Jerk, MC_BufferMode BufferMode, BOOL* Done, BOOL* Busy, BOOL* Active, BOOL*CommandAborted, BOOL* Error, WORD* ErrorID);
ksm_API void __stdcall MC_MoveVelocity(int Index, INT* QueueIndex, BOOL ContinuousUpdate, LREAL Velocity, LREAL Acceleration, LREAL Deceleration, LREAL Jerk, MC_Direction Direction, MC_BufferMode BufferMode, BOOL* InVelocity, BOOL* Busy, BOOL* Active, BOOL*CommandAborted, BOOL* Error, WORD* ErrorID);
ksm_API void __stdcall MC_Jog(int Index, INT* QueueIndex, BOOL JogForward, BOOL JogBackward, LREAL Velocity, LREAL Acceleration, LREAL Deceleration, LREAL Jerk, BOOL* InVelocity, BOOL* Done, BOOL* Busy, BOOL* CommandAborted, BOOL* Error, WORD* ErrorID);
ksm_API void __stdcall MC_Inch(int Index, INT* QueueIndex, BOOL InchForward, BOOL InchBackward, LREAL Distance, LREAL Velocity, LREAL Acceleration, LREAL Deceleration, LREAL Jerk, BOOL* InVelocity, BOOL* Done, BOOL* Busy, BOOL* CommandAborted, BOOL* Error, WORD* ErrorID);
ksm_API void __stdcall MC_MoveContinuousAbsolute(int Index, INT* QueueIndex, BOOL ContinuousUpdate, LREAL Position, LREAL EndVelocity, LREAL Velocity, LREAL Acceleration, LREAL Deceleration, LREAL Jerk, MC_Direction Direction, MC_BufferMode BufferMode, BOOL* InEndVelocity, BOOL* Busy, BOOL* Active, BOOL*CommandAborted, BOOL* Error, WORD* ErrorID);
ksm_API void __stdcall MC_MoveContinuousRelative(int Index, INT* QueueIndex, BOOL ContinuousUpdate, LREAL Distance, LREAL EndVelocity, LREAL Velocity, LREAL Acceleration, LREAL Deceleration, LREAL Jerk, MC_BufferMode BufferMode, BOOL* InEndVelocity, BOOL* Busy, BOOL* Active, BOOL*CommandAborted, BOOL* Error, WORD* ErrorID);
ksm_API void __stdcall MC_SetPosition(int Index, INT* QueueIndex, LREAL Position, BOOL Relative, MC_ExecutionMode ExecutionMode, BOOL* Done, BOOL* Busy, BOOL* Error, WORD* ErrorID);
ksm_API void __stdcall MC_SetOverride(int Index, BOOL Enable, LREAL VelFactor, LREAL AccFactor, LREAL JerkFactor, BOOL* Enabled, BOOL* Busy, BOOL* Error, WORD* ErrorID);
ksm_API void __stdcall MC_ReadParameter(int Index, BOOL Enable, MC_AxisParameter ParameterNumber, BOOL* Valid, BOOL* Busy, BOOL* Error, WORD* ErrorID, LREAL* Value);
ksm_API void __stdcall MC_ReadBoolParameter(int Index, BOOL Enable, MC_AxisParameter ParameterNumber, BOOL* Valid, BOOL* Busy, BOOL* Error, WORD* ErrorID, BOOL* Value);
ksm_API void __stdcall MC_WriteParameter(int Index, INT* QueueIndex, MC_AxisParameter ParameterNumber, LREAL Value, MC_ExecutionMode ExecutionMode, BOOL* Done, BOOL* Busy, BOOL* Error, WORD* ErrorID);
ksm_API void __stdcall MC_WriteBoolParameter(int Index, INT* QueueIndex, MC_AxisParameter ParameterNumber, BOOL Value, MC_ExecutionMode ExecutionMode, BOOL* Done, BOOL* Busy, BOOL* Error, WORD* ErrorID);
ksm_API void __stdcall MC_ReadDigitalInput(int Index, BOOL Enable, INT InputNumber, BOOL* Valid, BOOL* Busy, BOOL* Error, WORD* ErrorID, BOOL* Value);
ksm_API void __stdcall MC_ReadDigitalOutput(int Index, BOOL Enable, INT OutputNumber, BOOL* Valid, BOOL* Busy, BOOL* Error, WORD* ErrorID, BOOL* Value);
ksm_API void __stdcall MC_WriteDigitalOutput(int Index, INT* QueueIndex, INT OutputNumber, BOOL Value, MC_ExecutionMode ExecutionMode, BOOL* Done, BOOL* Busy, BOOL* Error, WORD* ErrorID);
ksm_API void __stdcall MC_ReadActualPosition(int Index, BOOL Enable, BOOL* Valid, BOOL* Busy, BOOL* Error, WORD* ErrorID, LREAL* Position);
ksm_API void __stdcall MC_ReadActualVelocity(int Index, BOOL Enable, BOOL* Valid, BOOL* Busy, BOOL* Error, WORD* ErrorID, LREAL* Velocity);
ksm_API void __stdcall MC_ReadActualTorque(int Index, BOOL Enable, BOOL* Valid, BOOL* Busy, BOOL* Error, WORD* ErrorID, LREAL* Torque);
ksm_API void __stdcall MC_ReadStatus(int Index, BOOL Enable, BOOL* Valid, BOOL* Busy, BOOL* Error, WORD* ErrorID, BOOL* ErrorStop, BOOL* Disabled, BOOL* Stopping, BOOL* Homing, BOOL* StandStill, BOOL* DiscreteMotion, BOOL* ContinuousMotion, BOOL* SynchronizedMotion);
ksm_API void __stdcall MC_ReadMotionState(int Index, BOOL Enable, MC_Source Source, BOOL* Valid, BOOL* Busy, BOOL* Error, WORD* ErrorID, BOOL* ConstantVelocity, BOOL* Accelerating, BOOL* Decelerating, BOOL* DirectionPositive, BOOL* DirectionNegative);
ksm_API void __stdcall MC_ReadAxisInfo(int Index, BOOL Enable, BOOL* Valid, BOOL* Busy, BOOL* Error, WORD* ErrorID, BOOL* HomeAbsSwitch, BOOL* LimitSwitchPos, BOOL* LimitSwitchNeg, BOOL* Simulation, BOOL* CommunicationReady, BOOL* ReadyForPowerOn, BOOL* PowerOn, BOOL* IsHomed, BOOL* AxisWarning);
ksm_API void __stdcall MC_ReadAxisError(int Index, BOOL Enable, BOOL* Valid, BOOL* Busy, BOOL* Error, WORD* ErrorID, WORD* AxisErrorID);
ksm_API void __stdcall MC_Reset(int Index, BOOL* Done, BOOL* Busy, BOOL* Error, WORD* ErrorID);
ksm_API void __stdcall MC_CamTableSelect(int index, MC_CamTable table, LREAL* masterPositions, LREAL* slavePositions, BOOL* done, BOOL* busy, BOOL* error, WORD* errorID);
ksm_API void __stdcall MC_CamIn(int Master, int Slave, INT* QueueIndex, BOOL ContinuousUpdate, LREAL MasterOffset, LREAL SlaveOffset, LREAL MasterScaling, LREAL SlaveScaling, MC_CamStartMode StartMode, LREAL StartParameter, MC_Source MasterValueSource, INT Cam, MC_BufferMode BufferMode, BOOL* InSync, BOOL* Busy, BOOL* Active, BOOL* CommandAborted, BOOL* Error, WORD* ErrorID, BOOL* EndOfProfile);
ksm_API void __stdcall MC_CamOut(int Index, BOOL* Done, BOOL* Busy, BOOL* Error, WORD* ErrorID);
ksm_API void __stdcall MC_CamInfo(int Index, BOOL Enable, BOOL* Valid, BOOL* Busy, BOOL* Error, WORD* ErrorID, BOOL* InSync, INT* RepetitionCount, INT* RowIndex, LREAL* SlaveTargetPosition);
ksm_API void __stdcall MC_CamSimulate(int Index, BOOL Enable, LREAL MasterPosition, LREAL MasterOffset, LREAL SlaveOffset, LREAL MasterScaling, LREAL SlaveScaling, BOOL* Valid, BOOL* Busy, BOOL* Error, WORD* ErrorID, INT* RepetitionCount, INT* RowIndex, LREAL* SlaveTargetPosition);
ksm_API void __stdcall MC_GearIn(int Master, int Slave, INT* QueueIndex, BOOL ContinuousUpdate, INT RatioNumerator, UINT RatioDenominator, MC_Source MasterValueSource, LREAL Acceleration, LREAL Deceleration, LREAL Jerk, MC_BufferMode BufferMode, BOOL* InGear, BOOL* Busy, BOOL* Active, BOOL* CommandAborted, BOOL* Error, WORD* ErrorID);
ksm_API void __stdcall MC_GearOut(int Index, BOOL* Done, BOOL* Busy, BOOL* Error, WORD* ErrorID);
ksm_API void __stdcall MC_GearInPos(int Master, int Slave, INT* QueueIndex, INT RatioNumerator, UINT RatioDenominator, MC_Source MasterValueSource, LREAL MasterSyncPosition, LREAL SlaveSyncPosition, MC_SyncMode SyncMode, LREAL MasterStartDistance, LREAL Velocity, LREAL Acceleration, LREAL Deceleration, LREAL Jerk, MC_BufferMode BufferMode, BOOL* StartSync, BOOL* InSync, BOOL* Busy, BOOL* Active, BOOL* CommandAborted, BOOL* Error, WORD* ErrorID);
ksm_API void __stdcall MC_TouchProbe(int Index, BOOL Execute, MC_ProbeTrigger TriggerInput, BOOL WindowOnly, LREAL FirstPosition, LREAL LastPosition, BOOL* Done, BOOL* Busy, BOOL* CommandAborted, BOOL* Error, WORD* ErrorID, LREAL* RecordedPosition);
ksm_API void __stdcall MC_AbortTrigger(int Index, MC_ProbeTrigger TriggerInput, BOOL* Done, BOOL* Busy, BOOL* Error, WORD* ErrorID);
ksm_API void __stdcall MC_DigitalCamSwitch(int Index, BOOL Enable, INT SwitchLength, MC_CamSwitch* Switches, INT TrackLength, MC_Output* Outputs, MC_Track* Tracks, DWORD EnableMask, MC_Source ValueSource, BOOL* InOperation, BOOL* Busy, BOOL* Error, WORD* ErrorID);
ksm_API void __stdcall CommandTest(int Index, INT* QueueIndex, LREAL Amplitude, BOOL* Done, BOOL* Busy, BOOL* CommandAborted, BOOL* Error, WORD* ErrorID);

ksm_API void __stdcall MC_AddAxisToGroup(int Index, INT AxisIndex, IDENT_IN_GROUP IdentInGroup, BOOL* Done, BOOL* Busy, BOOL* Error, WORD* ErrorID);
ksm_API void __stdcall MC_RemoveAxisFromGroup(int Index, IDENT_IN_GROUP IdentInGroup, BOOL* Done, BOOL* Busy, BOOL* Error, WORD* ErrorID);
ksm_API void __stdcall MC_UngroupAllAxes(int Index, BOOL* Done, BOOL* Busy, BOOL* Error, WORD* ErrorID);
ksm_API void __stdcall MC_GroupReadConfiguration(int Index, BOOL Enable, IDENT_IN_GROUP IdentInGroup, MC_CoordSystem CoordSystem, INT* AxisIndex, BOOL* Valid, BOOL* Busy, BOOL* Error, WORD* ErrorID);
ksm_API void __stdcall MC_GroupEnable(int Index, BOOL* Done, BOOL* Busy, BOOL* Error, WORD* ErrorID);
ksm_API void __stdcall MC_GroupDisable(int Index, BOOL* Done, BOOL* Busy, BOOL* Error, WORD* ErrorID);
ksm_API void __stdcall MC_GroupSetPosition(int Index, INT* QueueIndex, INT Length, LREAL* Position, BOOL Relative, MC_CoordSystem CoordSystem, MC_ExecutionMode ExecutionMode, BOOL* Done, BOOL* Busy, BOOL* Error, WORD* ErrorID);
ksm_API void __stdcall MC_GroupSetOverride(int Index, BOOL Enable, LREAL VelFactor, LREAL AccFactor, LREAL JerkFactor, BOOL* Enabled, BOOL* Busy, BOOL* Error, WORD* ErrorID);
ksm_API void __stdcall MC_GroupReadActualPosition(int Index, BOOL Enable, MC_CoordSystem CoordSystem, BOOL* Valid, BOOL* Busy, BOOL* Error, WORD* ErrorID, INT Length, LREAL* Position);
ksm_API void __stdcall MC_GroupReadActualVelocity(int Index, BOOL Enable, MC_CoordSystem CoordSystem, BOOL* Valid, BOOL* Busy, BOOL* Error, WORD* ErrorID, INT Length, LREAL* Velocity, LREAL* PathVelocity);
ksm_API void __stdcall MC_GroupReadActualAcceleration(int Index, BOOL Enable, MC_CoordSystem CoordSystem, BOOL* Valid, BOOL* Busy, BOOL* Error, WORD* ErrorID, INT Length, LREAL* Acceleration, LREAL* PathAcceleration);
ksm_API void __stdcall MC_GroupStop(int Index, INT* QueueIndex, BOOL Execute, LREAL Deceleration, LREAL Jerk, BOOL* Done, BOOL* Busy, BOOL* CommandAborted, BOOL* Error, WORD* ErrorID);
ksm_API void __stdcall MC_GroupHalt(int Index, INT* QueueIndex, LREAL Deceleration, LREAL Jerk, MC_BufferMode BufferMode, BOOL* Done, BOOL* Busy, BOOL* Active, BOOL* CommandAborted, BOOL* Error, WORD* ErrorID);
ksm_API void __stdcall MC_GroupReadStatus(int Index, BOOL Enable, BOOL* Valid, BOOL* Busy, BOOL* Error, WORD* ErrorID, BOOL* GroupMoving, BOOL* GroupHoming, BOOL* GroupErrorStop, BOOL* GroupStandby, BOOL* GroupStopping, BOOL* GroupDisabled);
ksm_API void __stdcall MC_GroupReadError(int Index, BOOL Enable, BOOL* Valid, BOOL* Busy, BOOL* Error, WORD* ErrorID, WORD* GroupErrorID);
ksm_API void __stdcall MC_GroupReset(int Index, BOOL* Done, BOOL* Busy, BOOL* Error, WORD* ErrorID);
ksm_API void __stdcall MC_MoveLinearAbsoluteEx(int Index, INT* QueueIndex, BOOL ContinuousUpdate, INT Length, LREAL* Position, LREAL Velocity, LREAL Acceleration, LREAL Deceleration, LREAL Jerk, MC_CoordSystem CoordSystem, MC_BufferMode BufferMode, MC_TransitionMode TransitionMode, LREAL* TransitionParameter, BOOL* Done, BOOL* Busy, BOOL* Active, BOOL* CommandAborted, BOOL* Error, WORD* ErrorID);
ksm_API void __stdcall MC_MoveLinearRelativeEx(int Index, INT* QueueIndex, BOOL ContinuousUpdate, INT Length, LREAL* Distance, LREAL Velocity, LREAL Acceleration, LREAL Deceleration, LREAL Jerk, MC_CoordSystem CoordSystem, MC_BufferMode BufferMode, MC_TransitionMode TransitionMode, LREAL* TransitionParameter, BOOL* Done, BOOL* Busy, BOOL* Active, BOOL* CommandAborted, BOOL* Error, WORD* ErrorID);
ksm_API void __stdcall MC_MoveLinearAdditive(int Index, INT* QueueIndex, BOOL ContinuousUpdate, INT Length, LREAL* Distance, LREAL Velocity, LREAL Acceleration, LREAL Deceleration, LREAL Jerk, MC_CoordSystem CoordSystem, MC_BufferMode BufferMode, MC_TransitionMode TransitionMode, LREAL* TransitionParameter, BOOL* Done, BOOL* Busy, BOOL* Active, BOOL* CommandAborted, BOOL* Error, WORD* ErrorID);
ksm_API void __stdcall MC_MoveCircularAbsolute(int Index, INT* QueueIndex, BOOL ContinuousUpdate, MC_CircMode CircMode, INT Length, LREAL* AuxPoint, LREAL* EndPoint, MC_CircPathChoice PathChoice, LREAL Velocity, LREAL Acceleration, LREAL Deceleration, LREAL Jerk, MC_CoordSystem CoordSystem, MC_BufferMode BufferMode, MC_TransitionMode TransitionMode, LREAL* TransitionParameter, BOOL* Done, BOOL* Busy, BOOL* Active, BOOL* CommandAborted, BOOL* Error, WORD* ErrorID);
ksm_API void __stdcall MC_MoveCircularRelative(int Index, INT* QueueIndex, BOOL ContinuousUpdate, MC_CircMode CircMode, INT Length, LREAL* AuxPoint, LREAL* EndPoint, MC_CircPathChoice PathChoice, LREAL Velocity, LREAL Acceleration, LREAL Deceleration, LREAL Jerk, MC_CoordSystem CoordSystem, MC_BufferMode BufferMode, MC_TransitionMode TransitionMode, LREAL* TransitionParameter, BOOL* Done, BOOL* Busy, BOOL* Active, BOOL* CommandAborted, BOOL* Error, WORD* ErrorID);
ksm_API void __stdcall MC_MoveCircularAdditive(int Index, INT* QueueIndex, BOOL ContinuousUpdate, MC_CircMode CircMode, INT Length, LREAL* AuxPoint, LREAL* EndPoint, MC_CircPathChoice PathChoice, LREAL Velocity, LREAL Acceleration, LREAL Deceleration, LREAL Jerk, MC_CoordSystem CoordSystem, MC_BufferMode BufferMode, MC_TransitionMode TransitionMode, LREAL* TransitionParameter, BOOL* Done, BOOL* Busy, BOOL* Active, BOOL* CommandAborted, BOOL* Error, WORD* ErrorID);
ksm_API void __stdcall MC_MoveHelicalAbsolute(int Index, INT* QueueIndex, BOOL ContinuousUpdate, MC_CircMode CircMode, INT Length, LREAL* AuxPoint, LREAL* EndPoint, MC_CircPathChoice PathChoice, LREAL Depth, LREAL Pitch, LREAL Velocity, LREAL Acceleration, LREAL Deceleration, LREAL Jerk, MC_CoordSystem CoordSystem, MC_BufferMode BufferMode, MC_TransitionMode TransitionMode, LREAL* TransitionParameter, BOOL* Done, BOOL* Busy, BOOL* Active, BOOL* CommandAborted, BOOL* Error, WORD* ErrorID);
ksm_API void __stdcall MC_MoveHelicalRelative(int Index, INT* QueueIndex, BOOL ContinuousUpdate, MC_CircMode CircMode, INT Length, LREAL* AuxPoint, LREAL* EndPoint, MC_CircPathChoice PathChoice, LREAL Depth, LREAL Pitch, LREAL Velocity, LREAL Acceleration, LREAL Deceleration, LREAL Jerk, MC_CoordSystem CoordSystem, MC_BufferMode BufferMode, MC_TransitionMode TransitionMode, LREAL* TransitionParameter, BOOL* Done, BOOL* Busy, BOOL* Active, BOOL* CommandAborted, BOOL* Error, WORD* ErrorID);
ksm_API void __stdcall MC_MoveHelicalAdditive(int Index, INT* QueueIndex, BOOL ContinuousUpdate, MC_CircMode CircMode, INT Length, LREAL* AuxPoint, LREAL* EndPoint, MC_CircPathChoice PathChoice, LREAL Depth, LREAL Pitch, LREAL Velocity, LREAL Acceleration, LREAL Deceleration, LREAL Jerk, MC_CoordSystem CoordSystem, MC_BufferMode BufferMode, MC_TransitionMode TransitionMode, LREAL* TransitionParameter, BOOL* Done, BOOL* Busy, BOOL* Active, BOOL* CommandAborted, BOOL* Error, WORD* ErrorID);
ksm_API void __stdcall MC_GroupAbortCommand(int Index, INT QueueIndex, BOOL* Done, BOOL* Error, WORD* ErrorID);
ksm_API void __stdcall MC_GroupJog(int Index, INT* QueueIndex, BOOL JogForward, BOOL JogBackward, INT Length, LREAL* Velocity, LREAL Acceleration, LREAL Deceleration, LREAL Jerk, MC_CoordSystem CoordSystem, BOOL* InVelocity, BOOL* Done, BOOL* Busy, BOOL* CommandAborted, BOOL* Error, WORD* ErrorID);
ksm_API void __stdcall MC_GroupInch(int Index, INT* QueueIndex, BOOL InchForward, BOOL InchBackward, INT Length, LREAL* Distance, LREAL* Velocity, LREAL Acceleration, LREAL Deceleration, LREAL Jerk, MC_CoordSystem CoordSystem, BOOL* InVelocity, BOOL* Done, BOOL* Busy, BOOL* CommandAborted, BOOL* Error, WORD* ErrorID);

ksm_API void __stdcall EC_ReadByteParameter(BOOL Axis, int Index, INT* QueueIndex, WORD ObjectIndex, BYTE SubIndex, BOOL* Done, BOOL* Busy, BOOL* Error, WORD* ErrorID, BYTE* Value);
ksm_API void __stdcall EC_ReadWordParameter(BOOL Axis, int Index, INT* QueueIndex, WORD ObjectIndex, BYTE SubIndex, BOOL* Done, BOOL* Busy, BOOL* Error, WORD* ErrorID, WORD* Value);
ksm_API void __stdcall EC_ReadDWordParameter(BOOL Axis, int Index, INT* QueueIndex, WORD ObjectIndex, BYTE SubIndex, BOOL* Done, BOOL* Busy, BOOL* Error, WORD* ErrorID, DWORD* Value);
ksm_API void __stdcall EC_ReadStringParameter(BOOL Axis, int Index, INT* QueueIndex, WORD ObjectIndex, BYTE SubIndex, INT Length, BOOL* Done, BOOL* Busy, BOOL* Error, WORD* ErrorID, CHAR* Value, INT* ReadLength);
ksm_API void __stdcall EC_WriteByteParameter(BOOL Axis, int Index, INT* QueueIndex, WORD ObjectIndex, BYTE SubIndex, BYTE Value, BOOL* Done, BOOL* Busy, BOOL* Error, WORD* ErrorID);
ksm_API void __stdcall EC_WriteWordParameter(BOOL Axis, int Index, INT* QueueIndex, WORD ObjectIndex, BYTE SubIndex, WORD Value, BOOL* Done, BOOL* Busy, BOOL* Error, WORD* ErrorID);
ksm_API void __stdcall EC_WriteDWordParameter(BOOL Axis, int Index, INT* QueueIndex, WORD ObjectIndex, BYTE SubIndex, DWORD Value, BOOL* Done, BOOL* Busy, BOOL* Error, WORD* ErrorID);
ksm_API void __stdcall EC_WriteStringParameter(BOOL Axis, int Index, INT* QueueIndex, WORD ObjectIndex, BYTE SubIndex, INT Length, CHAR* Value, BOOL* Done, BOOL* Busy, BOOL* Error, WORD* ErrorID);
ksm_API void __stdcall EC_ReadFile(BOOL Axis, int Index, BOOL Execute, BOOL Bootstrap, ULONG LocalPathLength, CHAR* LocalPath, ULONG FileNameLength, CHAR* FileName, ULONG Password, BOOL* Done, BOOL* Busy, BOOL* Error, WORD* ErrorID);
ksm_API void __stdcall EC_WriteFile(BOOL Axis, int Index, BOOL Execute, BOOL Bootstrap, ULONG LocalPathLength, CHAR* LocalPath, ULONG FileNameLength, CHAR* FileName, ULONG Password, BOOL* Done, BOOL* Busy, BOOL* Error, WORD* ErrorID);

ksm_API void __stdcall MC_Log(BOOL Execute, int Length, MC_LogChannel* Channels, int TriggerChannel, LREAL TriggerValue, MC_LogTriggerType TriggerType, LREAL Duration, BOOL* Done, BOOL* Busy, BOOL* Active, BOOL* Error, WORD* ErrorID);

/*Depreciated*/
ksm_API void __stdcall MC_MoveLinearAbsolute(int Index, INT* QueueIndex, INT Length, LREAL* Position, LREAL Velocity, LREAL Acceleration, LREAL Deceleration, LREAL Jerk, MC_CoordSystem CoordSystem, MC_BufferMode BufferMode, MC_TransitionMode TransitionMode, LREAL* TransitionParameter, BOOL* Done, BOOL* Busy, BOOL* Active, BOOL* CommandAborted, BOOL* Error, WORD* ErrorID);
ksm_API void __stdcall MC_MoveLinearRelative(int Index, INT* QueueIndex, INT Length, LREAL* Distance, LREAL Velocity, LREAL Acceleration, LREAL Deceleration, LREAL Jerk, MC_CoordSystem CoordSystem, MC_BufferMode BufferMode, MC_TransitionMode TransitionMode, LREAL* TransitionParameter, BOOL* Done, BOOL* Busy, BOOL* Active, BOOL* CommandAborted, BOOL* Error, WORD* ErrorID);
ksm_API int __stdcall DefineEcamTable(int Index, int Master, double StartingPoint, double Modulo, double Interval, double* Points);
ksm_API int __stdcall ReadEcamTable(int Index, int* Master, double* StartingPoint, double* Modulo, double* Interval, double* Points);


#ifdef __cplusplus
}
#endif
#endif