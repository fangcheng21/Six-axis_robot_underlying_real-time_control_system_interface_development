#include <iostream>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <cmath>

#include "CRobotEcrtInterface.h"
#define MEASURE_TIMING

//timespec时间结构体的加法
    static struct timespec timespec_add(struct timespec time1, struct timespec time2)
    {
        struct timespec result;

        if ((time1.tv_nsec + time2.tv_nsec) >= NSEC_PER_SEC) {
            result.tv_sec = time1.tv_sec + time2.tv_sec + 1;    // 纳秒满进1
            result.tv_nsec = time1.tv_nsec + time2.tv_nsec - NSEC_PER_SEC;
        } else {
            result.tv_sec = time1.tv_sec + time2.tv_sec;
            result.tv_nsec = time1.tv_nsec + time2.tv_nsec;
        }

        return result;
    };
//

    CRobotEcrtInterface::CRobotEcrtInterface()
    {
        m_mc = new MasterConfigs();

        m_moc[0] = new MotorConfigs();
        m_moc[1] = new MotorConfigs();
        m_moc[2] = new MotorConfigs();
        m_moc[3] = new MotorConfigs();
        m_moc[4] = new MotorConfigs();
        m_moc[5] = new MotorConfigs();

        m_urc = new UnityRobotConfigs(m_mc,m_moc[0],m_moc[1],m_moc[2],m_moc[3],m_moc[4],m_moc[5]);

        cycletime = {0, PERIOD_NS};
        pthread_mutex_init(&mutex,NULL);

    }

    CRobotEcrtInterface::~CRobotEcrtInterface()
    {

        pthread_mutex_destroy(&mutex);
        delete m_urc;
        delete m_moc[0];
        delete m_moc[1];
        delete m_moc[2];
        delete m_moc[3];
        delete m_moc[4];
        delete m_moc[5];

        delete m_mc;

    }

/********************************初始化部分********************************/
    //获取主站的指针 //请求主机进行实时操作 /*返回：-1表示请求失败，0表示成功*/
    int CRobotEcrtInterface::request_master()
    {
        m_mc->master = ecrt_request_master(0);

        return (!m_mc->master) ? -1 : 0;
    };

    //获取域指针创建新的进程数据域 /*返回：-1表示请求失败，0表示成功*/
    int CRobotEcrtInterface::create_master_domain()
    {
        m_urc->domain = ecrt_master_create_domain(m_urc->_master->master);

        return (!m_urc->domain) ? -1 : 0;
    };

    //获取从站配置指针 /*返回：-1表示请求失败，0表示成功*/
    int CRobotEcrtInterface::achieve_slave_config()
    {
        
        m_moc[0]->_sc = ecrt_master_slave_config(m_urc->_master->master,0,0,VID_PID);
        if (!m_moc[0]->_sc) 
            return -1;
        
        m_moc[1]->_sc = ecrt_master_slave_config(m_urc->_master->master,0,1,VID_PID);
        if (!m_moc[1]->_sc) 
            return -1;

        m_moc[2]->_sc = ecrt_master_slave_config(m_urc->_master->master,0,2,VID_PID);
        if (!m_moc[2]->_sc) 
            return -1;

        m_moc[3]->_sc = ecrt_master_slave_config(m_urc->_master->master,0,3,VID_PID);
        if (!m_moc[3]->_sc) 
            return -1;

        m_moc[4]->_sc = ecrt_master_slave_config(m_urc->_master->master,0,4,VID_PID);
        if (!m_moc[4]->_sc) 
            return -1;

        m_moc[5]->_sc = ecrt_master_slave_config(m_urc->_master->master,0,5,VID_PID);
        if (!m_moc[5]->_sc) 
            return -1;
    
        return 0;

    };

    //指定完整的PDO配置 /*返回：-1表示请求失败，0表示成功，并有输出显示*/
    int CRobotEcrtInterface::set_slave_config_pdo()
    {
        if (ecrt_slave_config_pdos(m_moc[0]->_sc, EC_END, device_syncs))
            return -1;
        
        if (ecrt_slave_config_pdos(m_moc[1]->_sc, EC_END, device_syncs))
            return -1;

        if (ecrt_slave_config_pdos(m_moc[2]->_sc, EC_END, device_syncs))
            return -1;

        if (ecrt_slave_config_pdos(m_moc[3]->_sc, EC_END, device_syncs))
            return -1;

        if (ecrt_slave_config_pdos(m_moc[4]->_sc, EC_END, device_syncs))
            return -1;

        if (ecrt_slave_config_pdos(m_moc[5]->_sc, EC_END, device_syncs))
            return -1;

        return 0;
    };

    //注册数据域PDO /*返回：-1表示请求失败，0表示成功*/
    int CRobotEcrtInterface::register_domain_reg_pdo()
    {
        if (ecrt_domain_reg_pdo_entry_list(m_urc->domain, m_urc->domain_regs)) 
            return -1;

        return 0;
    };

    //为从站配置SYNC信号 分布式时钟 /*固定循环时间为1ms,可在PERIOD_NS处修改*/
    void CRobotEcrtInterface::set_slave_dc()
    {
        //循环时间1ms
        ecrt_slave_config_dc(m_moc[0]->_sc, 0x0300, PERIOD_NS, 4400000, 0, 0);
        ecrt_slave_config_dc(m_moc[1]->_sc, 0x0300, PERIOD_NS, 4400000, 0, 0);
        ecrt_slave_config_dc(m_moc[2]->_sc, 0x0300, PERIOD_NS, 4400000, 0, 0);
        ecrt_slave_config_dc(m_moc[3]->_sc, 0x0300, PERIOD_NS, 4400000, 0, 0);
        ecrt_slave_config_dc(m_moc[4]->_sc, 0x0300, PERIOD_NS, 4400000, 0, 0);
        ecrt_slave_config_dc(m_moc[5]->_sc, 0x0300, PERIOD_NS, 4400000, 0, 0);
    };

    //将上述6个函数联合 /*返回：-1表示请求失败，0表示成功*/
    int CRobotEcrtInterface::robot_unit_config()
    {
        int rel;

        rel = request_master();
        if(rel != 0)
            return -1;


        rel = create_master_domain();
        if(rel != 0)
            return -1;

        rel = achieve_slave_config();
        if(rel != 0)
            return -1;

        rel = set_slave_config_pdo();
        if(rel != 0)
            return -1;

        rel = register_domain_reg_pdo();
        if(rel != 0)
            return -1;

        set_slave_dc();

        return 0;
    };


    //读写SDO必须要在激活主站之前 
    //写 SDO  /*参数：关节类，主索引，次索引，写入数据地址指针，写入数据长度，中止地址*/
    void CRobotEcrtInterface::WriteSdoObject(int motorID, int ObIndex, int ObSubIndex, unsigned char* Value, size_t size, uint32_t *abort_code)
    {
        uint32_t *abort_code1;
        m_urc->req_real = ecrt_slave_config_create_sdo_request(m_moc[motorID]->_sc, ObIndex, ObSubIndex, size);
	
	    ecrt_sdo_request_timeout(m_urc->req_real, 500); // ms
	    ecrt_sdo_request_read(m_urc->req_real);          // retry reading

        ecrt_master_sdo_download(m_urc->_master->master, motorID, ObIndex, ObSubIndex, Value,  size, abort_code1);

    };

    //读 SDO /*参数：关节类，主索引，次索引，写入数据地址指针，写入数据长度，中止地址*/
    void CRobotEcrtInterface::ReadSdoObject(int motorID, int ObIndex, int ObSubIndex, unsigned char* Value, size_t size, uint32_t *abort_code)
    {

        size_t *result_size;
        uint32_t *abort_code2;

        m_urc->req_real = ecrt_slave_config_create_sdo_request(m_moc[motorID]->_sc, ObIndex, ObSubIndex, size);

	    ecrt_sdo_request_timeout(m_urc->req_real, 500); // ms
	    ecrt_sdo_request_read(m_urc->req_real);          // retry reading
    
        ecrt_master_sdo_upload(m_urc->_master->master, motorID, ObIndex, ObSubIndex, Value, size, result_size, abort_code2);
    
    }


    //主站正式激活函数 /*返回：-1表示请求失败，0表示成功*/
    int CRobotEcrtInterface::active_master()
    {
        if (ecrt_master_activate(m_urc->_master->master))
            return -1;
        return 0;
    };

    //接收数据域的地址 /*返回：-1表示请求失败，0表示成功，并有输出显示*/
    int CRobotEcrtInterface::achieve_domain_data()
    {
        m_urc->domain_pd= ecrt_domain_data(m_urc->domain);
        if (!m_urc->domain_pd) 
            return -1;
        return 0;
    };

    //激活主站，开启实时控制 /*返回：-1表示请求失败，0表示成功*/
    int CRobotEcrtInterface::active_master_configs()
    {
        int rel;
        rel = active_master();
        if(rel != 0)
            return -1;

        rel = achieve_domain_data();
        if(rel != 0)
            return -1;

        return 0;
    };





  /**************************************************************************/
    /***********************************控制部分********************************/
    //下载主站数据 /*参数：主站指针*/
    void CRobotEcrtInterface::receive_master_data(MasterConfigs &mc)
    {
        ecrt_master_receive(mc.master);
    };

    //下载domain数据 /*参数：URC类*/
    void CRobotEcrtInterface::receive_domain_data(UnityRobotConfigs &urc)
    {
        ecrt_domain_process(urc.domain);
    };

    //下载数据 （联合上述两个）/*参数：URC类*/
    void CRobotEcrtInterface::receive_data()
    {
        receive_master_data(*m_urc->_master);
        receive_domain_data(*m_urc);
    };

    //上传domain数据 /*参数：URC类*/
    void CRobotEcrtInterface::send_domain_data()
    {
        //pthread_mutex_lock(&mutex);
        ecrt_domain_queue(m_urc->domain);
        //pthread_mutex_unlock(&mutex);  
    };



    //上传从站数据 /*参数：主站指针*/
    void CRobotEcrtInterface::send_master_data(MasterConfigs &mc)
    {
        ecrt_master_send(mc.master);
    };

    //上传数据 （联合上述两个）/*参数：URC类*/ 
    void CRobotEcrtInterface::send_data()
    {
        ecrt_domain_queue(m_urc->domain);
        send_master_data(*m_urc->_master);
    };

    // //dc时间控制   
    // //将应用时间时间戳写入主站
    // void CRobotEcrtInterface::master_application_time()
    // {

    //     //ecrt_master_application_time(m_urc->_master->master, TIMESPEC2NS(m_urc->wakeupTime));
    // };

    //将当前系统时间戳发送给参考时钟 
    //参考时钟发送给所有从站，以实现dc时钟同步/*参数：URC类，循环标志符 （int sync_ref_counter = 1）*/
    void CRobotEcrtInterface::master_sync_reference_slave_clock(unsigned int sync_ref_counter)
    {
        struct timespec times;
        clock_gettime(CLOCK_REALTIME, &(times));
        ecrt_master_application_time(m_urc->_master->master, TIMESPEC2NS(times));
    
        if (sync_ref_counter) {
                sync_ref_counter--;
        } else {
            sync_ref_counter = 1; //每个同步周期

            ecrt_master_sync_reference_clock_to(m_urc->_master->master, TIMESPEC2NS(times));
        }

        ecrt_master_sync_slave_clocks(m_urc->_master->master);
    };

    /*状态检测*/
    //结合上述两函数实现1000循环检测  /*参数：URC类，外部定义记数数 （int cycle_counter = 0）*/
    void CRobotEcrtInterface::cycle_check_domain_master_slave_state(int cycle_counter)
    {
        //进程状态检测
        ec_domain_state_t ds;

        ecrt_domain_state(m_urc->domain, &ds);
        if (ds.working_counter != m_urc->domain_state.working_counter)
            printf("Domain1: WC %u.\n", ds.working_counter);
        if (ds.wc_state != m_urc->domain_state.wc_state)
            printf("Domain1: State %u.\n", ds.wc_state);

        m_urc->domain_state = ds;

        //主从站状态检测
        if (!(cycle_counter % 1000)) {

            ec_master_state_t ms;
            ecrt_master_state(m_urc->_master->master, &ms);

            if (ms.slaves_responding != m_urc->_master->master_state.slaves_responding)
                printf("%u slave(s).\n", ms.slaves_responding);
            if (ms.al_states != m_urc->_master->master_state.al_states)
                printf("AL states: 0x%02X.\n", ms.al_states);
            if (ms.link_up != m_urc->_master->master_state.link_up)
                printf("Link is %s.\n", ms.link_up ? "up" : "down");

            m_urc->_master->master_state = ms;


            //从站状态检测
            ec_slave_config_state_t s[6];
    
            //从站
            for(int i=0;i<6;i++)
            {
                ecrt_slave_config_state(m_moc[i]->_sc, &s[i]);
                if (s[i].al_state != m_moc[i]->_sc_state.al_state)
                {
                    printf("slave1: State 0x%02X.\n", s[i].al_state);
                }
                if (s[i].online != m_moc[i]->_sc_state.online)
                {
                    printf("slave1: %s.\n", s[i].online ? "online" : "offline");
                }
                if (s[i].operational != m_moc[i]->_sc_state.operational)
                {
                    printf("slave1: %soperational.\n", s[i].operational ? "" : "Not ");
                }
                m_moc[i]->_sc_state = s[i];
            }   
	    }
        cycle_counter++;
    };

    //绝对睡眠1ms  /*参数：URC类*/ 
    void CRobotEcrtInterface::AbsoluteSleep()
    {
        m_urc->wakeupTime = timespec_add(m_urc->wakeupTime, cycletime);
        clock_nanosleep(CLOCK_REALTIME, TIMER_ABSTIME, &(m_urc->wakeupTime), NULL);
    };

    void CRobotEcrtInterface::SyncTime(struct timespec &times)
    {
        struct timespec delatytime = {0, 500000L}; 
        times = timespec_add(m_urc->wakeupTime , delatytime );
        // times = m_urc->wakeupTime;
    }

    void CRobotEcrtInterface::AbsoluteSleep(struct timespec &times)
    {
        times = timespec_add(times, cycletime);
        clock_nanosleep(CLOCK_REALTIME, TIMER_ABSTIME, &(times), NULL);
    };


    //使能 最大等待时间15s /*参数：URC类，关节类 返回：-1表示请求失败，1表示成功*/
    int CRobotEcrtInterface::ServoOn(int MotorID)
    {
        uint16_t status; 
        uint32_t position; 
        uint16_t command=0x027F; //判断状态字
        int cycle_counter = 0;
        unsigned int sync_ref_counter = 1;

        struct timespec FlagTime = {0,0};   //循环15s视为报错

        struct timespec times;
        SyncTime(times);
        //times = m_urc->wakeupTime;

        while(true)
        {

            FlagTime = timespec_add(FlagTime, cycletime);
            if(FlagTime.tv_sec > 15)
                break;

            
            AbsoluteSleep(times);
            //clock_gettime(CLOCK_MONOTONIC, &times);
            // times = timespec_add(times, cycletime);
            // clock_nanosleep(CLOCK_REALTIME, TIMER_ABSTIME, &(times), NULL);

            //下载数据
            receive_data();

            //状态检测
            //cycle_check_domain_master_slave_state(cycle_counter);


            status = EC_READ_U16(m_urc->domain_pd+m_moc[MotorID]->_offset.status_word);

            if( (status & command) == 0x0208 )  //故障
            {
                EC_WRITE_U16(m_urc->domain_pd+m_moc[MotorID]->_offset.ctrl_word, 0x0080);   //执行清除故障
            }
            else if( (status & command) == 0x0250 ) //伺服无故障
            {
                EC_WRITE_U16(m_urc->domain_pd+m_moc[MotorID]->_offset.ctrl_word, 0x0006 );   //切换伺服准备
            }
            else if( (status & command) == 0x0231)  //伺服准备好
            {
                EC_WRITE_U16(m_urc->domain_pd+m_moc[MotorID]->_offset.ctrl_word, 0x0007 ); //切换等待打开伺服使能
            }
            else if( (status & command) == 0x0233)  //等待打开使能
            {
		    position = EC_READ_U32(m_urc->domain_pd+m_moc[MotorID]->_offset.position_actual_value);
                EC_WRITE_U32(m_urc->domain_pd+m_moc[MotorID]->_offset.target_position, position );//输入当前位置
                EC_WRITE_U8(m_urc->domain_pd+m_moc[MotorID]->_offset.operation_mode, 0x8); 
                EC_WRITE_U16(m_urc->domain_pd+m_moc[MotorID]->_offset.ctrl_word, 0x000f );//打开使能，伺服运行
            }
            else if( (status & command) == 0x0237)  //伺服运行
            {
                std::cout<<"Motor"<<MotorID<<": servo succeed"<<std::endl;
                break;
            }

            //master_sync_reference_slave_clock(sync_ref_counter);

            send_domain_data(); 

            //上传数据
            //send_data();
        }

        return ((status & command) == 0x0237)?0:-1;
    };

    //去使能 /*参数：URC类，关节类 返回：-1表示请求失败，1表示成功*/
    int CRobotEcrtInterface::ServoOff(int MotorID)
    {
        uint16_t status; 
        uint16_t command=0x027F;//判断状态字
        int cycle_counter = 0;
        unsigned int sync_ref_counter = 0;

        struct timespec FlagTime = {0,0};

        struct timespec times;
        SyncTime(times);
        //times = m_urc->wakeupTime;

        while(true)
        {
        
            FlagTime = timespec_add(FlagTime, cycletime);
            if(FlagTime.tv_sec > 15)
                break;

            AbsoluteSleep(times);
            // times = timespec_add(times, cycletime);
            // clock_nanosleep(CLOCK_REALTIME, TIMER_ABSTIME, &(times), NULL);

            //下载数据
            receive_data();

            //状态检测
            //cycle_check_domain_master_slave_state(cycle_counter);


            status = EC_READ_U16(m_urc->domain_pd+m_moc[MotorID]->_offset.status_word);

            if( (status & command) == 0x0208 )  //故障
            {
                EC_WRITE_U16(m_urc->domain_pd+m_moc[MotorID]->_offset.ctrl_word, 0x0080);   //执行清除故障
            }
            else if( (status & command) == 0x0237 )  //伺服运行
            {
                EC_WRITE_U16(m_urc->domain_pd+m_moc[MotorID]->_offset.ctrl_word, 0x0007);   //切换等待打开伺服使能
            }
            else if( (status & command) == 0x0233 ) //等待打开使能
            {
                EC_WRITE_U16(m_urc->domain_pd+m_moc[MotorID]->_offset.ctrl_word, 0x0006 );   //切换伺服准备
            }
            else if( (status & command) == 0x0231)  //伺服准备好
            {
                EC_WRITE_U16(m_urc->domain_pd+m_moc[MotorID]->_offset.ctrl_word, 0x0000 ); //切换伺服无故障
            }
            else if( (status & command) == 0x0250) 
            {
                std::cout<<"Motor"<<MotorID<<": servo off succeed"<<std::endl;
                break;
            }

            //master_sync_reference_slave_clock(sync_ref_counter);

            //上传数据
            send_domain_data();
            //send_data(); 
        }


        return ((status & command) == 0x0250)?1:-1;

    };

    //获取电机状态字 /*参数：URC类, 关节类moc， uint16_t状态字*/ 
    void CRobotEcrtInterface::GetServoStatus(int MotorID, uint16_t &Status)
    {
        Status = EC_READ_U16(m_urc->domain_pd+m_moc[MotorID]->_offset.status_word);
    };

    //获取错误代码 /*参数：URC类, 关节类moc， uint16_t错误代码*/ 
    void CRobotEcrtInterface::GetServoError(int MotorID, uint16_t &Error)
    {
        Error = EC_READ_U16(m_urc->domain_pd+m_moc[MotorID]->_offset.error_code);
    };

    //获取实际转矩 /*参数：URC类, 关节类moc， int16_t实际转矩*/
    void CRobotEcrtInterface::GetServoTorque(int MotorID, int16_t &Torque)
    {
        Torque = EC_READ_U16(m_urc->domain_pd+m_moc[MotorID]->_offset.torque_actual_value);
    };

    //获取目标转矩 /*参数：URC类, 关节类moc， int16_t目标转矩*/
    void CRobotEcrtInterface::GetServoTargetTorque(int MotorID, int16_t &Torque)
    {
        Torque = EC_READ_U16(m_urc->domain_pd+m_moc[MotorID]->_offset.target_torque); 
    };

    //获取实际位置 /*参数：URC类, 关节类moc， int32_t实际位置*/
    void CRobotEcrtInterface::GetServoPosition(int MotorID, int32_t &Position)
    {
        Position = EC_READ_U32(m_urc->domain_pd+m_moc[MotorID]->_offset.position_actual_value);
    };

    //获取目标位置 /*参数：URC类, 关节类moc， int32_t目标位置*/
    void CRobotEcrtInterface::GetServoTargetPosition(int MotorID, int32_t &Position)
    {
        Position = EC_READ_U32(m_urc->domain_pd+m_moc[MotorID]->_offset.target_position);
    };

    //获取运动模式代码  /*参数：URC类, 关节类moc， int8_t运动模式*/
    void CRobotEcrtInterface::GetServoControlMode(int MotorID, int8_t &Mode)
    {
        Mode = EC_READ_U8(m_urc->domain_pd+m_moc[MotorID]->_offset.operation_mode);
    };

    //快速停止运动  /*参数：URC类, 关节类moc*/
    void CRobotEcrtInterface::StopServo(int MotorID)
    {
        EC_WRITE_U16(m_urc->domain_pd+m_moc[MotorID]->_offset.ctrl_word, 0x0002);
    };

    //报警复位  /*参数：URC类, 关节类moc*/
    void CRobotEcrtInterface::ResetServoAlarm(int MotorID)
    {
        EC_WRITE_U16(m_urc->domain_pd+m_moc[MotorID]->_offset.ctrl_word, 0x0080);   
    };

    //控制运动模式 /*参数：URC类, 关节类moc， int8_t运动模式*/
    void CRobotEcrtInterface::SetServoControlMode(int MotorID, int8_t Mode)
    {
        EC_WRITE_U8(m_urc->domain_pd+m_moc[MotorID]->_offset.operation_mode, Mode);      
    };

    //控制位置 /*参数：URC类, 关节类moc， int32_t 目标位置*/
    void CRobotEcrtInterface::SetServoTargetPosition(int MotorID,int32_t Position)
    {
        EC_WRITE_U32(m_urc->domain_pd+m_moc[MotorID]->_offset.target_position, Position); 
    };

    //控制转矩 /*参数：URC类, 关节类moc， int16_t 目标转矩*/
    void CRobotEcrtInterface::SetServoTorque(int MotorID, int16_t Torque)
    {
        EC_WRITE_U16(m_urc->domain_pd+m_moc[MotorID]->_offset.target_torque, Torque); 
    };

    //IO部分全部暂停
    //output 4位 
    void CRobotEcrtInterface::ReadOutputBit(UnityRobotConfigs &urc, MotorConfigs &moc,int Bitoffset, bool &value)
    {
    
    uint32_t digital_output;
    uint32_t COMAND = 0x00010000;

    digital_output = EC_READ_U32(urc.domain_pd + moc._offset.drives_digital_outputs);

    if((digital_output & (COMAND << Bitoffset)) == (COMAND << Bitoffset))
    {
        value = true;
    }
    else{value = false;};
    };

    //IO
    void CRobotEcrtInterface::WriteOutputBit(UnityRobotConfigs &urc, MotorConfigs &moc,int Bitoffset, bool value)
    {

        uint32_t digital_output;
        uint32_t COMAND = 0x00010000;
        bool value1;
        //读取IO值
        digital_output = EC_READ_U32(urc.domain_pd + moc._offset.drives_digital_outputs);
        if((digital_output & (COMAND << Bitoffset)) != (COMAND << Bitoffset))
        {
            value1 = true;
        }
        else{value1 = false;};

        //目标值与期望值不同
        if(value1 != value)
        {
            //期望是1,则加，是0,则减
            if(value = true)
            {
                digital_output = digital_output + (COMAND << Bitoffset);
            }
            else
                digital_output = digital_output - (COMAND << Bitoffset);
        }

        EC_WRITE_U32(urc.domain_pd + moc._offset.drives_digital_outputs, digital_output); 
    };

    //input 6位
    void CRobotEcrtInterface::ReadInputBit(UnityRobotConfigs &urc, MotorConfigs &moc,int Bitoffset, bool &value)
    {
        uint32_t digital_intput;
        uint32_t COMAND = 0x00010000;

        digital_intput = EC_READ_U32(urc.domain_pd + moc._offset.drives_digital_inputs);

        if((digital_intput & (COMAND << Bitoffset)) == (COMAND << Bitoffset))
        {
            value = true;
        }
        else{value = false;};
    };

   

    //关闭连接 /*参数：URC类*/
    void CRobotEcrtInterface::StopLink()
    {
        m_urc->StateHandler_run = false;
        sleep(2);
        ecrt_release_master(m_urc->_master->master);
    };

    

    //机器臂心跳线程
    void *StateHandler_thread(void *arg)
    {
        CRobotEcrtInterface *_RCI = (CRobotEcrtInterface *)arg;

        int cycle_counter = 0;
        unsigned int sync_ref_counter = 0;

        cpu_set_t cpuset;
        CPU_ZERO(&cpuset);
        CPU_SET(2,&cpuset);
        CPU_SET(3,&cpuset);

        sched_setaffinity(0, sizeof(cpuset), &cpuset);
        sched_getaffinity(0, sizeof(cpuset), &cpuset);

#ifdef MEASURE_TIMING
    int num = 0;
    int tag = 20; 
    struct timespec startTime, endTime, lastStartTime = {};
    uint32_t period_ns = 0, exec_ns = 0, latency_ns = 0,
             latency_min_ns = 0, latency_max_ns = 0,
             period_min_ns = 0, period_max_ns = 0,
             exec_min_ns = 0, exec_max_ns = 0;
#endif

        //获取系统时间，赋值公用时间戳
        clock_gettime(CLOCK_REALTIME, &(_RCI->m_urc->wakeupTime));
        while (_RCI->m_urc->StateHandler_run) 
        {

                //pthread_mutex_lock(&(_RCI->mutex));
#ifdef MEASURE_TIMING
        clock_gettime(CLOCK_REALTIME, &startTime);

        period_ns = DIFF_NS(lastStartTime, startTime);
        lastStartTime = startTime;

        if (period_ns > period_max_ns) {
            period_max_ns = period_ns;
        }
        
#endif
                // send process data
                

                //pthread_mutex_unlock(&(_RCI->mutex)); 

               
                // receive EtherCAT
                _RCI->receive_data();

                //_RCI->cycle_check_domain_master_slave_state(cycle_counter);

                    uint16_t status1 = EC_READ_U16(_RCI->m_urc->domain_pd+_RCI->m_moc[0]->_offset.status_word);
                    uint16_t status2 = EC_READ_U16(_RCI->m_urc->domain_pd+_RCI->m_moc[1]->_offset.status_word);
                    uint16_t status3 = EC_READ_U16(_RCI->m_urc->domain_pd+_RCI->m_moc[2]->_offset.status_word);
                    uint16_t status4 = EC_READ_U16(_RCI->m_urc->domain_pd+_RCI->m_moc[3]->_offset.status_word);
                    uint16_t status5 = EC_READ_U16(_RCI->m_urc->domain_pd+_RCI->m_moc[4]->_offset.status_word);
                    uint16_t status6 = EC_READ_U16(_RCI->m_urc->domain_pd+_RCI->m_moc[5]->_offset.status_word);
                
                //std::cout<<std::hex<<status1<<" "<<std::hex<<status2<<" "<<std::hex<<status3<<" "<<std::hex<<status4<<" "<<std::hex<<status5<<" "<<std::hex<<status6<<" "<<std::endl;

                _RCI->master_sync_reference_slave_clock(sync_ref_counter);

                _RCI->send_data();
                
#ifdef MEASURE_TIMING
	if(num == 1000)
	{
	   // 输出时间统计数据
            printf("period     %10u ... %10u\n",period_ns/1000, period_max_ns);
            std::cout<<std::hex<<status1<<" "<<std::hex<<status2<<" "<<std::hex<<status3<<" "<<std::hex<<status4<<" "<<std::hex<<status5<<" "<<std::hex<<status6<<" "<<std::endl;        
  		if(tag)
  		{
  			period_max_ns = 0;
  			//tag--;
  		}
            
        period_min_ns = 0xffffffff;
        num = 0;
	}
	num++;
#endif
                
                _RCI->AbsoluteSleep();
                
        }
        std::cout<<"心跳线程退出"<<std::endl;
        return NULL;
    };

    //开启心跳线程 /*参数：URC类*/
    int CRobotEcrtInterface::Statehandler_pth()
    {


        m_urc->param = {};
        m_urc->param.sched_priority = sched_get_priority_max(SCHED_FIFO); 
        pthread_attr_init(&(m_urc->thattr));


        pthread_attr_setschedpolicy(&(m_urc->thattr), SCHED_FIFO);
        pthread_attr_setschedparam(&(m_urc->thattr), &(m_urc->param));

        int ret = pthread_create(&(m_urc->pth), &(m_urc->thattr), StateHandler_thread, (void*)this);
        if (ret) {
            fprintf(stderr, "%s: pthread_create cyclic task failed\n",
                    strerror(-ret));
		    return -1;
        }
        return 0;
    };

    //模拟正弦运动控制 /*参数：URC类，关节*/
    int CRobotEcrtInterface::controlMove(int MotorID,int flag)
    {
        uint16_t status; 
        int32_t position;
        int32_t position1;
        int32_t position2;
     
        uint16_t command=0x027F; //判断状态字
        int cycle_counter = 0;
        unsigned int sync_ref_counter = 1;
        int tag= 1;
        int tag1= 1;
        int tag2= 1;

        double counters1 = 0;  //临时
        struct timespec times;
        SyncTime(times);
        //times = m_urc->wakeupTime;
        
        while(counters1<=10)
        {
            AbsoluteSleep(times);
            // times = timespec_add(times, cycletime);
            // clock_nanosleep(CLOCK_REALTIME, TIMER_ABSTIME, &(times), NULL);

            //下载数据
            receive_data();
            //状态检测
            //cycle_check_domain_master_slave_state(cycle_counter);



            GetServoStatus(MotorID,status);        
            //std::cout <<"control:" <<std::hex<<status << std::endl;

            if( (status & command) == 0x0237)  //伺服运行
            {
                if(counters1 <=10)
                {
                    if(tag)
                    {
                        GetServoPosition(MotorID,position);
                        //std::cout<<std::dec<<position<<std::endl;

                        int8_t mode;
                        GetServoControlMode(MotorID,mode);
                        //std::cout<<"mode:"<<std::hex<<(int)mode<<std::endl;

                        tag = 0;
                    }


                    GetServoTargetPosition(MotorID,position2);
                    uint32_t delty =  21233664 / 4.0 * (1 - std::cos(M_PI / 5 * counters1));
                    //std::cout<<position+delty<<std::endl;
                    // if(flag == 1)
                    // {
                         SetServoTargetPosition(MotorID,position+delty);
                    // }
                    // else if(flag == -1)
                    // {
                    //     SetServoTargetPosition(MotorID,position-delty);
                    // }
                    GetServoPosition(MotorID,position1);
                    //std::cout<<position2<<" "<<position+delty<<" "<<position1<<std::endl;
                }
                // else if((counters1 >10) &&(counters1 <15))
                // {
                //     if(tag1)
                //     {
                //         SetServoControlMode(MotorID,0xA);

                //     //测试rpdo是否可读
                //         int32_t rppos;
                //         GetServoTargetPosition(MotorID,rppos);
                //         std::cout<<"rppos:"<< std::dec << rppos <<std::endl;
                //     //测试结束

                //         int8_t mode;
                //         GetServoControlMode(MotorID,mode);
                //         std::cout<<"mode:"<<std::hex<<(int)mode<<std::endl;
                    

                //         tag1 = 0;
                //     }
                
                //     SetServoTorque(MotorID,0);

                //     // int16_t torq;
                //     // GetServoTorque(urc,moc,torq);
                //     // std::cout<<"实际力矩： "<<torq<<std::endl;
                //     // int16_t torq1;
                //     // GetServoTargetTorque(urc,moc,torq1);
                //     // std::cout<<"目标力矩： "<<torq1<<std::endl;
                // }
                // else if(counters1 >=15)
                // {
                //     if(tag2)
                //     {
                //         GetServoPosition(MotorID,position1);
                //         SetServoTargetPosition(MotorID,position1);
                //         SetServoControlMode(MotorID,0x8);
                //         tag2=0;
                //     }
                //     uint32_t delty1 =  21233664 / 8.0 * (1 - std::cos(M_PI / 5 * (counters1-15)));
                //     SetServoTargetPosition(MotorID,position1+delty1);
                // }

            
                    
            }
            else {
                break;
            }


        // if(counters1 >= 19)
        // {
        //         StopServo(urc,moc);
        //         std::cout<<"快速停止"<<std::endl;
        // }

        
            counters1 +=0.001;

            //master_sync_reference_slave_clock(sync_ref_counter);
            //上传数据
            send_domain_data();
            //send_data();
        }
    
        return 1;
    };

