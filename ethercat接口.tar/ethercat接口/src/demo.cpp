#include <iostream>
#include <sys/mman.h>  //锁定内存
#include <sched.h> /* sched_setscheduler() */ //线程调度
#include <unistd.h>    //sleep()
#include <cmath>

#include <pthread.h>    //多线程

#include "CRobotEcrtInterface.h"

//实例化
static CRobotEcrtInterface REI;

//运动线程标志
static int runtag;
//读线程标志
static int readtag;

void *Control(void*)
{
    int num = 0;

        cpu_set_t cpuset;
        CPU_ZERO(&cpuset);
        CPU_SET(2,&cpuset);
        CPU_SET(3,&cpuset);

        sched_setaffinity(0, sizeof(cpuset), &cpuset);
        sched_getaffinity(0, sizeof(cpuset), &cpuset);

    while(runtag)
    {
        //num++;
        REI.controlMove(3,1); //第4轴
        //sleep(1);
        // REI.controlMove(4,-1); //第5轴
        // sleep(1);
    }
}

void *Read(void*)
{
    struct timespec times;
    REI.SyncTime(times);
    int sync_ref_counter  = 1;
    uint16_t Error;
    int32_t Position;

    int num = 0;
    while(readtag)
    {
        REI.AbsoluteSleep(times);
        //下载数据
        REI.receive_data();

        //读取数据
        //REI.GetServoError(4,Error);
        REI.GetServoPosition(3,Position);

        num++;
        if(6000 < num && num < 10000)
        {
            
            //std::cout<<Position<<std::endl;
        }

        //REI.master_sync_reference_slave_clock(sync_ref_counter);
        //上传数据
        //REI.send_data();
    }
}

int main()
{
    readtag = 1;
    runtag = 1;
    if (mlockall(MCL_CURRENT | MCL_FUTURE) == -1) 
    {
        perror("mlockall failed");
        return -1;
    }

    cpu_set_t cpuset;
    CPU_ZERO(&cpuset);
    CPU_SET(2,&cpuset);
    CPU_SET(3,&cpuset);
    
    //ethercat配置
    REI.robot_unit_config();


    //激活主站前读写SDO
    uint32_t abort_code;
    // uint32_t brake = 1;
    // WriteSdoObject(URC, Joint5, 0x4602, 00, (uint8_t*)&brake,sizeof(brake), &abort_code);

    // brake = 0;
    // sleep(2);
    // std::cout<<"1"<<std::endl;
    // WriteSdoObject(URC, Joint5, 0x4602, 00, (uint8_t*)&brake,sizeof(brake), &abort_code);


    // uint32_t abort_code1;
    // int32_t pos;
    // ReadSdoObject(URC,Joint5,0x6064,00,(uint8_t*)&pos,sizeof(pos),&abort_code1);
    // std::cout<<pos<<std::endl;

    // ReadSdoObject(URC,Joint5,0x6064,00,(uint8_t*)&pos,sizeof(pos),&abort_code1);
    // std::cout<<pos<<std::endl;


    sleep(2);
    
    //激活主站
    REI.active_master_configs();

    //开启心跳
    REI.Statehandler_pth();

    /* Create cyclic RT-thread */
    //修改主线程的调度策略以及调度参数
    struct sched_param param1 = {};
    struct sched_param param2 = {};
    struct sched_param param3 = {};

    param1.sched_priority = sched_get_priority_max(SCHED_FIFO);  //获取最大抢占优先级;
    param2.sched_priority = sched_get_priority_max(SCHED_FIFO); 
    param3.sched_priority = sched_get_priority_max(SCHED_FIFO); 

    sched_setaffinity(0, sizeof(cpuset), &cpuset);
    sched_getaffinity(0, sizeof(cpuset), &cpuset);
    if (sched_setscheduler(0, SCHED_FIFO, &param1) == -1) 
    {
        perror("sched_setscheduler failed");
    }

    pthread_attr_t attr;
	pthread_t tid;
	pthread_attr_init(&attr);

    //修改支线程的调度策略
    //pthread_setaffinity_np(tid,sizeof(cpuset), &cpuset);
    //pthread_getaffinity_np(tid,sizeof(cpuset), &cpuset);
    pthread_attr_setschedpolicy(&attr, SCHED_RR);
	pthread_attr_setschedparam (&attr, &param2);

    pthread_attr_t attr1;
	pthread_t tid1;
	pthread_attr_init(&attr1);

    //修改支线程的调度策略
    pthread_attr_setschedpolicy(&attr1, SCHED_RR);
	pthread_attr_setschedparam (&attr1, &param3);

    sleep(10);
    
    std::cout << "使能"<<std::endl;
    REI.ServoOn(0);
    sleep(1);
	REI.ServoOn(1);
    sleep(1);
    REI.ServoOn(2);
    sleep(1);
    REI.ServoOn(3);
    sleep(1);
    REI.ServoOn(4);
    sleep(1);
    //REI.ServoOn(5);
    std::cout << "使能完毕"<<std::endl;



    sleep(3);

    //此处为简单运动实例，可进CPP文件中浏览
    std::cout << "运动"<<std::endl;
        //controlMove(3);
    //REI.controlMove(4); //第5轴
    //REI.controlMove(4); //第5轴
        //controlMove(5);
    //std::cout << "运动完毕"<<std::endl;
    pthread_create(&tid, &attr, Control, NULL);
    //pthread_create(&tid1, &attr1, Read, NULL);


    std::cin.ignore();

    std::cout << "停止运动"<<std::endl;
    readtag = 0;
    runtag = 0;
    sleep(10);

    std::cout << "去使能"<<std::endl;
    REI.ServoOff(0);
    sleep(1);
    REI.ServoOff(1);
    sleep(1);
    REI.ServoOff(2);
    sleep(1);
    REI.ServoOff(3);
    sleep(1);
    REI.ServoOff(4);
    sleep(1);
    REI.ServoOff(5);
    std::cout << "去使能完毕"<<std::endl;

    sleep(1);
    std::cout << "断开连接"<<std::endl;
    REI.StopLink();
    pthread_join(tid, NULL);
    pthread_join(tid1, NULL);

    return 0;
}
